const { boot, sleep } = require('./harness');
const EVIL = {
  operations: [{ id: 'op_id_zzzz_aaaa', name: 'Evil', createdDate: '2026-01-01' },
               { id: 'op_id_q"><img src=x onerror=window.__pwnedOpt=1>', name: 'Evil2', createdDate: '2026-01-01' }],
  currentOperationId: 'op_id_zzzz_aaaa',
  op_id_zzzz_aaaa_team: [{ id: 'x" autofocus onfocus="window.__pwnedId=1', name: 'A', role: 'TL', phone: '1' }],
  op_id_zzzz_aaaa_eventDocuments: [{ id: 'd1', title: 't', dataUrl: 'javascript:window.__pwnedUrl=1', fileName: 'a' }],
  appLock: { salt: 'aa', pinHash: 'bb', recoveryHash: 'cc' },
  disclaimerAcceptance: { version: '1.2', acceptedAt: '2026-01-01T00:00:00Z' },
  saferoute_evil: 'x',
  '__proto__': { polluted: true }
};
async function run(label, root) {
  const r = await boot({ root, page: 'index.html' });
  const w = r.window, d = r.doc;
  d.getElementById('disclaimerAcceptBtn') && d.getElementById('disclaimerAcceptBtn').click();
  await sleep(100);
  const json = JSON.stringify(EVIL).replace('"__proto__"', '"__proto__"');  // JSON.stringify drops __proto__ own key? force it in text
  const text = json.slice(0, -1) + ',"__proto__":{"polluted":true}}';
  const file = new w.File([text], 'evil.json', { type: 'application/json' });
  const res = await new Promise(resolve => w.CP.storage.importAll(file, (err, result) => resolve({ err: err && err.message, result })));
  const out = { label, importResult: res };
  out.appLockOverwritten = w.localStorage.getItem('cpapp_appLock') !== null;
  out.forgedAcceptance = (w.localStorage.getItem('cpapp_disclaimerAcceptance') || '').includes('2026-01-01');
  out.protoPolluted = ({}).polluted === true || w.Object.prototype.polluted === true;
  // render the segments that hit the sinks
  w.CP.storage.setCurrentOperationId('op_id_zzzz_aaaa');
  const hits = {};
  for (const key of ['dashboard', 'team', 'eventSecurity']) {
    w.location.hash = '#' + key; w.dispatchEvent(new w.HashChangeEvent('hashchange')); await sleep(30);
    const bad = [...d.querySelectorAll('*')].filter(e => [...e.attributes].some(a => /^on/i.test(a.name)));
    hits[key] = bad.map(e => e.tagName + ':' + [...e.attributes].map(a => a.name).filter(n => /^on/i.test(n)).join(','));
    const jsHref = [...d.querySelectorAll('a[href]')].filter(a => /^\s*javascript:/i.test(a.getAttribute('href'))).length;
    if (jsHref) hits[key].push('javascript:-href x' + jsHref);
  }
  out.injectedAttributes = hits;
  out.exploitWorked = Object.values(hits).some(v => v.length);
  console.log(JSON.stringify(out, null, 1));
}
(async () => {
  await run('ORIGINAL root', (process.env.ORIG || '/home/claude/orig'));
  await run('PATCHED root', (process.env.ROOT || '/home/claude/cp'));
  process.exit(0);
})();
