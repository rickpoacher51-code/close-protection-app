const { boot, sleep } = require('./harness');
async function run(label, root, page) {
  const r = await boot({ root, page });
  const w = r.window, d = r.doc;
  const out = { label, page };
  out.disclaimerShown = !!d.getElementById('disclaimerOverlay');
  const btn = d.getElementById('disclaimerAcceptBtn');
  if (btn) btn.click();
  await sleep(150);
  out.overlayGone = !d.getElementById('disclaimerOverlay');
  out.navCount = w.CP.NAV.length;
  const failed = [];
  for (const seg of w.CP.NAV) {
    w.location.hash = '#' + seg.key;
    w.dispatchEvent(new w.HashChangeEvent('hashchange'));
    await sleep(15);
    const c = d.getElementById('content');
    if (!c.innerHTML || /failed to load/.test(c.textContent)) failed.push(seg.key);
    // any inline event-handler attributes anywhere in the DOM?
    const inl = [...d.querySelectorAll('*')].filter(e => [...e.attributes].some(a => /^on/i.test(a.name)));
    if (inl.length) failed.push(seg.key + ':inline-handler');
  }
  out.segmentsFailed = failed;
  out.errors = r.errors;
  out.inlineScripts = [...d.scripts].filter(s => !s.src).length;
  console.log(JSON.stringify(out));
}
(async () => {
  await run('PATCHED root', (process.env.ROOT || '/home/claude/cp'), 'index.html');
  await run('PATCHED beta', (process.env.ROOT || '/home/claude/cp'), 'beta/index.html');
  await run('ORIGINAL root', (process.env.ORIG || '/home/claude/orig'), 'index.html');
  await run('ORIGINAL beta', (process.env.ORIG || '/home/claude/orig'), 'beta/index.html');
  process.exit(0);
})();
