const { boot, sleep } = require('./harness');
let pass = 0, fail = 0; const failures = [];
function ok(name, cond, extra) { if (cond) { pass++; console.log('PASS  ' + name); } else { fail++; failures.push(name); console.log('FAIL  ' + name + (extra ? '  -> ' + extra : '')); } }
const goto = async (r, key) => { r.window.location.hash = '#' + key; r.window.dispatchEvent(new r.window.HashChangeEvent('hashchange')); await sleep(30); };
const acceptSeed = w => w.localStorage.setItem('cpbeta_disclaimerAcceptance', JSON.stringify({ version: '1.2', acceptedAt: 'x' }));
const doImport = (w, obj) => new Promise(res => w.CP.storage.importAll(new w.File([typeof obj === 'string' ? obj : JSON.stringify(obj)], 'b.json'), (err, result) => res({ err, result })));
const inlineHandlers = d => [...d.querySelectorAll('*')].filter(e => [...e.attributes].some(a => /^on/i.test(a.name))).length;

(async () => {
  const PROD = w => {
    w.localStorage.setItem('cpapp_operations', JSON.stringify([{ id: 'op_id_aa_bb', name: 'Prod op', createdDate: '2026-01-01' }]));
    w.localStorage.setItem('cpapp_currentOperationId', 'op_id_aa_bb');
    w.localStorage.setItem('cpapp_op_id_aa_bb_team', JSON.stringify([{ id: 'id_1', name: 'Alice' }]));
    w.localStorage.setItem('cpapp_appLock', JSON.stringify({ salt: 's', pinHash: 'h', recoveryHash: 'r' }));
    w.localStorage.setItem('cpapp_disclaimerAcceptance', JSON.stringify({ version: '1.2', acceptedAt: 'x' }));
  };
  // --- BEFORE: original beta reading a device that also has the production app's data
  { const r = await boot({ root: (process.env.ORIG || '/home/claude/orig'), page: 'beta/index.html', seed: PROD }); const w = r.window, d = r.doc;
    const opts = [...d.querySelectorAll('#opSelect option')].map(o => o.textContent);
    await goto(r, 'team');
    console.log('INFO  ORIGINAL beta on a device with prod data: op switcher lists', JSON.stringify(opts), '| team table shows Alice:', /Alice/.test(d.getElementById('content').textContent));
  }
  // --- AFTER
  { const r = await boot({ root: (process.env.ROOT || '/home/claude/cp'), page: 'beta/index.html', seed: PROD }); const w = r.window, d = r.doc;
    ok('beta: terms screen now shown on first run', !!d.getElementById('disclaimerOverlay'));
    d.getElementById('disclaimerAcceptBtn').click(); await sleep(150);
    ok('beta: app boots after accepting', d.getElementById('content').innerHTML.length > 100 && r.errors.length === 0, r.errors.join('|'));
    const keys = Object.keys(w.localStorage);
    ok('beta: writes only cpbeta_* keys', keys.filter(k => k.startsWith('cpbeta_')).length > 0);
    ok('beta: production keys (data, PIN config, terms acceptance) untouched', w.localStorage.getItem('cpapp_appLock') === JSON.stringify({ salt: 's', pinHash: 'h', recoveryHash: 'r' }) && w.localStorage.getItem('cpapp_op_id_aa_bb_team') !== null && JSON.parse(w.localStorage.getItem('cpapp_operations')).length === 1);
    ok('beta: does not list the production app\'s operations', ![...d.querySelectorAll('#opSelect option')].some(o => /Prod op/.test(o.textContent)));
    // new operation via header
    d.getElementById('newOpBtn').click(); await sleep(30);
    ok('beta: creating an operation works', w.CP.ops.list().length === 2);
    // hostile full backup
    const evil = { _exportType: 'full-backup', data: {
      operations: [{ id: 'id_aaa_bbb', name: 'Evil', status: 'live', createdAt: '2026-01-01T00:00:00Z' }, { id: 'bad"id', name: 'x' }],
      currentOpId: 'id_aaa_bbb',
      op_id_aaa_bbb_team: [{ id: 'x" autofocus onfocus="window.__pwned=1', name: 'A', role: 'TL' }],
      op_id_aaa_bbb_advanceVenues: [{ id: 'v1', venueName: 'V', address: 'a" onmouseover="1' }],
      appLock: { salt: 'aa', pinHash: 'bb' }, disclaimerAcceptance: { version: '1.2' }, evilKey: 'x', '../x': 1 } };
    const res = await doImport(w, evil);
    ok('beta import: hostile full backup handled (allow-list + cleaning)', !res.err && res.result.imported === 4 && res.result.skipped >= 3 && res.result.sanitized >= 2, JSON.stringify(res));
    ok('beta import: PIN/terms records not written', w.localStorage.getItem('cpbeta_appLock') === null && w.localStorage.getItem('cpbeta_evilKey') === null);
    w.CP.ops.setCurrent('id_aaa_bbb'); await goto(r, 'team'); await goto(r, 'advance');
    ok('beta import: rendered pages contain no injected event-handler attributes', inlineHandlers(d) === 0);
    // production backup refused
    const prod = await doImport(w, { operations: [{ id: 'op_id_x_y', name: 'P' }], currentOperationId: 'op_id_x_y', op_id_x_y_team: [] });
    ok('beta import: a production-app backup is refused instead of writing junk keys', prod.err && prod.err.message === 'production backup' && !Object.keys(w.localStorage).some(k => /op_op_id/.test(k)));
    // single operation
    const single = await doImport(w, { _exportType: 'single-operation', _operation: { name: 'S' + 'x'.repeat(400), client: 'C' }, data: { team: [{ id: 'q"><i onclick=1>', name: 'n' }], 'bad key!': 1, appLock: 1, operations: [] } });
    ok('beta import: single-operation file cleaned, odd/reserved keys skipped', !single.err && single.result.imported === 1 && single.result.skipped === 3 && single.result.sanitized === 1 && w.CP.ops.get(w.CP.ops.current()).name.length < 200, JSON.stringify(single));
    // garbage
    const g1 = await doImport(w, '[1,2,3]'); const g2 = await doImport(w, 'not json');
    ok('beta import: arrays and non-JSON rejected', !!g1.err && !!g2.err);
    // export excludes lock/acceptance
    w.localStorage.setItem('cpbeta_appLock', '{"x":1}');
    w.CP.storage.exportAllOperations(); const full = JSON.parse(r.blobs[r.blobs.length - 1]);
    ok('beta export: full backup excludes PIN config and terms record', !('appLock' in full.data) && !('disclaimerAcceptance' in full.data));
    // links
    await goto(r, 'uklaws');
    ok('beta: UK Laws shows corrected content + sources', /Beckford/.test(d.getElementById('content').textContent) && d.querySelectorAll('.law-item a').length >= 9);
    // storage full
    const realSet = w.Storage.prototype.setItem; w.Storage.prototype.setItem = function () { throw new w.DOMException('full', 'QuotaExceededError'); };
    let threw = false; try { w.CP.storage.save('team', [{ id: 'id_a', name: 'x' }]); } catch (e) { threw = !!e.cpAlerted; }
    w.Storage.prototype.setItem = realSet;
    ok('beta: failed save is loud, not silent', threw && r.alerts.some(a => /NOT saved/.test(a)));
    // navigate everything one more time
    let bad = 0; for (const seg of w.CP.NAV) { await goto(r, seg.key); if (/failed to load/.test(d.getElementById('content').textContent)) bad++; }
    ok('beta: all ' + w.CP.NAV.length + ' sections render', bad === 0 && r.errors.length === 0, r.errors.join('|'));
  }
  console.log(`\nBETA RESULT: ${pass} passed, ${fail} failed`); if (fail) console.log('FAILED: ' + failures.join(' | '));
  process.exit(fail ? 1 : 0);
})().catch(e => { console.error('HARNESS ERROR', e); process.exit(2); });
