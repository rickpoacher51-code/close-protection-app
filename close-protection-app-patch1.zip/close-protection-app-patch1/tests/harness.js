const { JSDOM, requestInterceptor, VirtualConsole } = require('jsdom');
const fs = require('fs'), path = require('path');
const { webcrypto } = require('crypto');

const MIME = { '.js': 'application/javascript', '.css': 'text/css', '.html': 'text/html', '.json': 'application/json', '.png': 'image/png', '.jpg': 'image/jpeg', '.pdf': 'application/pdf' };
function makeInterceptor(root) {
  return requestInterceptor((request) => {
    const u = new URL(request.url);
    if (u.host !== 'app.test') return;
    const rel = decodeURIComponent(u.pathname).replace(/^\/close-protection-app\//, '');
    const p = path.join(root, rel);
    try {
      const buf = fs.readFileSync(p);
      return new Response(buf, { headers: { 'Content-Type': MIME[path.extname(p)] || 'application/octet-stream' } });
    } catch (e) { return new Response('not found', { status: 404 }); }
  });
}

// opts: root (repo dir), page ('index.html' | 'beta/index.html'), seed (fn(window) run before scripts), quota (bool)
async function boot(opts) {
  const root = opts.root, page = opts.page || 'index.html';
  const html = fs.readFileSync(path.join(root, page), 'utf8');
  const errors = [], alerts = [], blobs = [];
  const vc = new VirtualConsole();
  vc.on('jsdomError', e => errors.push('jsdomError: ' + (e.detail && e.detail.message || e.message)));
  vc.on('error', (...a) => errors.push('console.error: ' + a.join(' ')));
  const dom = new JSDOM(html, {
    url: 'https://app.test/close-protection-app/' + page,
    runScripts: 'dangerously', resources: { interceptors: [makeInterceptor(root)] }, pretendToBeVisual: true, virtualConsole: vc,
    beforeParse(window) {
      Object.defineProperty(window, 'crypto', { value: webcrypto, configurable: true });
      window.TextEncoder = TextEncoder; window.TextDecoder = TextDecoder;
      window.Uint8Array = Uint8Array; window.ArrayBuffer = ArrayBuffer; window.Uint32Array = Uint32Array;
      window.alert = m => alerts.push(String(m)); window.confirm = () => true; window.prompt = (m, d) => d || 'test-device';
      window.URL.createObjectURL = () => 'blob:test'; window.URL.revokeObjectURL = () => {};
      window.HTMLAnchorElement.prototype.click = function () {};
      const RealBlob = window.Blob;
      window.Blob = function (parts, o) { blobs.push(parts.join('')); return new RealBlob(parts, o); };
      window.Blob.prototype = RealBlob.prototype;
      window.__errors = errors;
      if (opts.seed) opts.seed(window);
    }
  });
  await new Promise(r => dom.window.addEventListener('load', r));
  await new Promise(r => setTimeout(r, 60));
  return { dom, window: dom.window, doc: dom.window.document, errors, alerts, blobs };
}
const sleep = ms => new Promise(r => setTimeout(r, ms));
module.exports = { boot, sleep };
