const { boot, sleep } = require('./harness');
const fs = require('fs'), path = require('path'), vm = require('vm');
const { webcrypto } = require('crypto');
const ROOT = process.env.ROOT || '/home/claude/cp';
let pass = 0, fail = 0; const failures = [];
function ok(name, cond, extra) { if (cond) { pass++; console.log('PASS  ' + name); } else { fail++; failures.push(name); console.log('FAIL  ' + name + (extra ? '  -> ' + extra : '')); } }
const accept = async (r) => { const b = r.doc.getElementById('disclaimerAcceptBtn'); if (b) b.click(); await sleep(120); };
const goto = async (r, key) => { r.window.location.hash = '#' + key; r.window.dispatchEvent(new r.window.HashChangeEvent('hashchange')); await sleep(30); };
const ACCEPTED = w => w.localStorage.setItem('cpapp_disclaimerAcceptance', JSON.stringify({ version: '1.2', acceptedAt: '2026-09-20T00:00:00Z' }));

(async () => {
  // ---------- Disclaimer ----------
  { const r = await boot({ root: ROOT }); const w = r.window;
    ok('disclaimer: v1.2', w.CP.disclaimer.VERSION === '1.2');
    ok('disclaimer: live cap placeholder removed', !/cap to be set|\[£/.test(w.CP.disclaimer.HTML));
    ok('disclaimer: business-use, licence, third-party, privacy clauses present', ['Business use', 'Licence and ownership', 'Third-party links', 'Privacy Policy'].every(t => w.CP.disclaimer.HTML.includes(t)));
    ok('disclaimer: death/personal-injury carve-out retained', /death or personal injury/.test(w.CP.disclaimer.HTML));
    await accept(r); await sleep(80);
    const rec = JSON.parse(w.localStorage.getItem('cpapp_disclaimerAcceptance'));
    ok('disclaimer: acceptance stores version + timestamp + SHA-256 of accepted text', rec.version === '1.2' && !!rec.acceptedAt && /^[0-9a-f]{64}$/.test(rec.textSha256 || ''), JSON.stringify(rec));
  }
  { const r = await boot({ root: ROOT, seed: w => w.localStorage.setItem('cpapp_disclaimerAcceptance', JSON.stringify({ version: '1.1', acceptedAt: 'x' })) });
    ok('disclaimer: users who accepted v1.1 are asked to accept v1.2', !!r.doc.getElementById('disclaimerOverlay')); }

  // ---------- Legacy credential purge / SafeRoute untouched ----------
  { const r = await boot({ root: ROOT, seed: w => { ACCEPTED(w); w.localStorage.setItem('cpops_security_pinHash', 'x'); w.localStorage.setItem('cpops_security_pinSalt', 'y'); w.localStorage.setItem('cpops_security_recoveryHash', 'z'); w.localStorage.setItem('saferoute_rv_plans', '[]'); } });
    const w = r.window;
    ok('purge: orphaned cpops_security_* PIN hashes deleted', ['pinHash', 'pinSalt', 'recoveryHash'].every(k => w.localStorage.getItem('cpops_security_' + k) === null));
    ok('purge: SafeRoute keys left alone', w.localStorage.getItem('saferoute_rv_plans') === '[]'); }

  // ---------- Lock ----------
  { const r = await boot({ root: ROOT, seed: ACCEPTED }); const w = r.window, L = w.CP.lock;
    ok('lock: off by default', !L.isEnabled());
    const words = await new Promise(res => L.setNewPin('123456', res));
    const cfg = w.CP.storage.loadGlobal('appLock');
    ok('lock: new config uses PBKDF2-SHA256 @ 600k, 6-word recovery phrase', cfg.pinKdf === 'pbkdf2-sha256' && cfg.recoveryKdf === 'pbkdf2-sha256' && cfg.iter === 600000 && words.length === 6 && cfg.pinHash.length === 64);
    const good = await new Promise(res => L.verifyPin('123456', (ok_, info) => res(ok_)));
    ok('lock: correct PIN accepted', good === true);
    const bad = await new Promise(res => L.verifyPin('000000', (o, i) => res([o, i])));
    ok('lock: wrong PIN rejected, not yet locked out', bad[0] === false && !bad[1].lockedMs);
    for (let i = 0; i < 4; i++) await new Promise(res => L.verifyPin('000001', () => res()));
    const locked = await new Promise(res => L.verifyPin('123456', (o, i) => res([o, i])));
    ok('lock: after 5 failures even the RIGHT PIN is refused during back-off', locked[0] === false && locked[1].lockedMs > 20000, JSON.stringify(locked));
    w.CP.storage.removeGlobal('lockAttempts');
    const rec = await new Promise(res => L.verifyRecoveryPhrase(words.join(' ').toUpperCase(), (o) => res(o)));
    ok('lock: recovery phrase verifies (case/space-insensitive)', rec === true);
    // legacy upgrade
    const enc = new TextEncoder(); const sha = async s => Buffer.from(await webcrypto.subtle.digest('SHA-256', enc.encode(s))).toString('hex');
    const legacy = { salt: 'abcd1234abcd1234abcd1234abcd1234', pinHash: await sha('abcd1234abcd1234abcd1234abcd1234:pin:654321'), recoveryHash: await sha('abcd1234abcd1234abcd1234abcd1234:phrase:one two three four five six'), updatedDate: '2026-08-01' };
    w.CP.storage.saveGlobal('appLock', legacy);
    const up = await new Promise(res => L.verifyPin('654321', o => res(o)));
    const cfg2 = w.CP.storage.loadGlobal('appLock');
    ok('lock: legacy SHA-256 PIN verifies and is upgraded to PBKDF2 in place', up === true && cfg2.pinKdf === 'pbkdf2-sha256' && cfg2.pinHash !== legacy.pinHash);
    const up2 = await new Promise(res => L.verifyPin('654321', o => res(o)));
    ok('lock: upgraded hash still verifies', up2 === true);
    const legRec = await new Promise(res => L.verifyRecoveryPhrase('one two three four five six', o => res(o)));
    ok('lock: legacy recovery hash still verifies', legRec === true);
    ok('lock: settings text says data is NOT encrypted', (() => { const c = r.doc.createElement('div'); L.renderSettings(c); return /not encrypted/.test(c.textContent); })());
  }
  // startup overlay + unlock + relock
  { const cfgHolder = {};
    const enc = new TextEncoder();
    const salt = '00112233445566778899aabbccddeeff';
    const key = await webcrypto.subtle.importKey('raw', enc.encode('pin:246810'), 'PBKDF2', false, ['deriveBits']);
    const bits = await webcrypto.subtle.deriveBits({ name: 'PBKDF2', salt: enc.encode(salt), iterations: 600000, hash: 'SHA-256' }, key, 256);
    const pinHash = Buffer.from(bits).toString('hex');
    const r = await boot({ root: ROOT, seed: w => { ACCEPTED(w); w.localStorage.setItem('cpapp_appLock', JSON.stringify({ salt, iter: 600000, pinKdf: 'pbkdf2-sha256', recoveryKdf: 'pbkdf2-sha256', pinHash, recoveryHash: 'x' })); } });
    const w = r.window, d = r.doc;
    ok('lock: startup shows PIN screen and app content is not rendered behind it', !!d.getElementById('lockOverlay') && d.getElementById('content').innerHTML === '');
    d.getElementById('lockPinInput').value = '000000';
    d.getElementById('lockPinForm').dispatchEvent(new w.Event('submit', { cancelable: true })); await sleep(1500);
    ok('lock: wrong PIN shows error and stays locked', /Incorrect PIN/.test(d.getElementById('lockError').textContent) && !!d.getElementById('lockOverlay'));
    d.getElementById('lockPinInput').value = '246810';
    d.getElementById('lockPinForm').dispatchEvent(new w.Event('submit', { cancelable: true })); await sleep(1500);
    ok('lock: correct PIN unlocks and app renders', !d.getElementById('lockOverlay') && d.getElementById('content').innerHTML.length > 100);
    // relock after 5+ minutes in background
    const realNow = w.Date.now;
    Object.defineProperty(d, 'visibilityState', { value: 'hidden', configurable: true }); d.dispatchEvent(new w.Event('visibilitychange'));
    w.Date.now = () => realNow.call(w.Date) + 6 * 60 * 1000;
    Object.defineProperty(d, 'visibilityState', { value: 'visible', configurable: true }); d.dispatchEvent(new w.Event('visibilitychange')); await sleep(50);
    ok('lock: re-locks after 6 minutes in the background', !!d.getElementById('lockOverlay'));
  }

  // ---------- Share (encrypted) ----------
  { const r = await boot({ root: ROOT, seed: ACCEPTED }); const w = r.window, d = r.doc;
    const env = await w.CP.share.encrypt({ hello: 'world' }, 'correct horse battery');
    ok('share: new files are v2', env.v === 2);
    const back = await w.CP.share.decrypt(env, 'correct horse battery');
    ok('share: v2 round-trip', back.hello === 'world');
    let rejected = false; try { await w.CP.share.decrypt(env, 'wrong wrong wrong!'); } catch (e) { rejected = true; }
    ok('share: wrong passphrase rejected', rejected);
    // v1 legacy file (150k) built independently
    const enc = new TextEncoder(); const salt = webcrypto.getRandomValues(new Uint8Array(16)), iv = webcrypto.getRandomValues(new Uint8Array(12));
    const km = await webcrypto.subtle.importKey('raw', enc.encode('oldpin'), 'PBKDF2', false, ['deriveKey']);
    const k = await webcrypto.subtle.deriveKey({ name: 'PBKDF2', salt, iterations: 150000, hash: 'SHA-256' }, km, { name: 'AES-GCM', length: 256 }, false, ['encrypt']);
    const ct = new Uint8Array(await webcrypto.subtle.encrypt({ name: 'AES-GCM', iv }, k, enc.encode(JSON.stringify({ legacy: true }))));
    const b64 = u => Buffer.from(u).toString('base64');
    const old = await w.CP.share.decrypt({ v: 1, salt: b64(salt), iv: b64(iv), data: b64(ct) }, 'oldpin');
    ok('share: existing v1 (150k) files from teammates still open', old.legacy === true);
    let junk = false; try { await w.CP.share.decrypt({ v: 9, salt: 'a', iv: 'b', data: 'c' }, 'x'); } catch (e) { junk = true; }
    ok('share: malformed/unknown envelope rejected cleanly', junk);
    // UI enforcement
    await goto(r, 'export');
    d.getElementById('shareOutPin').value = 'abcd';
    d.getElementById('shareOutForm').dispatchEvent(new w.Event('submit', { cancelable: true })); await sleep(30);
    ok('share UI: 4-character passphrase refused (min 12)', /at least 12/.test(d.getElementById('shareOutError').textContent));
    const before = r.blobs.length;
    d.getElementById('shareOutPin').value = 'correct horse battery';
    d.getElementById('shareOutForm').dispatchEvent(new w.Event('submit', { cancelable: true })); await sleep(1500);
    const produced = r.blobs.slice(before).find(b => b.includes('"v":2'));
    ok('share UI: 12+ char passphrase produces a v2 encrypted file', !!produced);
    // hostile payload
    const res = w.CP.share.importAsNewOperation({ _operationName: 'X'.repeat(500), team: [{ id: 'bad id"><b onclick=1>', name: 'n' }], eventDocuments: [{ id: 'a', dataUrl: 'javascript:alert(1)' }], junk: { a: 1 } });
    const ops = w.CP.storage.getOperations(); const newOp = ops.find(o => o.id === res.id);
    const tk = w.localStorage.getItem('cpapp_' + res.id + '_team'), dk = w.localStorage.getItem('cpapp_' + res.id + '_eventDocuments');
    ok('share import: hostile ids replaced, unsafe attachment dropped, name capped', res.sanitized >= 2 && /^id_/.test(JSON.parse(tk)[0].id) && JSON.parse(dk)[0].dataUrl === '' && newOp.name.length < 200, JSON.stringify({ res, name: newOp && newOp.name.length }));
  }

  // ---------- Export / backup ----------
  { const r = await boot({ root: ROOT, seed: ACCEPTED }); const w = r.window, d = r.doc;
    w.localStorage.setItem('cpapp_appLock', JSON.stringify({ salt: 's', pinHash: 'h', recoveryHash: 'r' }));
    w.CP.storage.exportAll();
    const json = JSON.parse(r.blobs[r.blobs.length - 1]);
    ok('export: backup contains NO PIN hashes / acceptance / lastBackup', !('appLock' in json) && !('disclaimerAcceptance' in json) && !('lastBackup' in json), Object.keys(json).join(','));
    ok('export: real data still included', 'operations' in json);
    ok('export: last-backup date recorded', !!w.CP.storage.getLastBackup());
    await goto(r, 'dashboard');
    ok('dashboard: backup panel shows last backup', /Last backup exported/.test(d.getElementById('backupStatus').textContent) && !/Back up now/.test(d.getElementById('backupStatus').textContent));
  }
  { const r = await boot({ root: ROOT, seed: ACCEPTED }); const d = r.doc; await goto(r, 'dashboard');
    ok('dashboard: warns when no backup has ever been exported', /No backup has been exported/.test(d.getElementById('backupStatus').textContent) && /Back up now/.test(d.getElementById('backupStatus').textContent)); }

  // ---------- Storage full ----------
  { const r = await boot({ root: ROOT, seed: ACCEPTED }); const w = r.window;
    w.CP.storage.save('team', [{ id: 'id_a', name: 'ok' }]);
    const realSet = w.Storage.prototype.setItem;
    w.Storage.prototype.setItem = function () { throw new w.DOMException('full', 'QuotaExceededError'); };
    let threw = null; try { w.CP.storage.save('team', [{ id: 'id_a', name: 'big' }]); } catch (e) { threw = e; }
    w.Storage.prototype.setItem = realSet;
    ok('quota: a failed save is loud (alert) and flagged so callers do not double-alert', !!threw && threw.cpAlerted === true && r.alerts.some(a => /NOT saved/.test(a)), JSON.stringify(r.alerts));
  }

  // ---------- CRUD + ids ----------
  { const r = await boot({ root: ROOT, seed: ACCEPTED }); const w = r.window, d = r.doc; await goto(r, 'team');
    d.getElementById('crudAddBtn').click(); await sleep(20);
    const form = d.getElementById('crudForm'); form.querySelector('[name=name]').value = 'Test Op <b>x</b>'; 
    form.dispatchEvent(new w.Event('submit', { cancelable: true })); await sleep(30);
    const list = w.CP.storage.load('team', []);
    ok('crud: record created with generated id', list.length === 1 && /^id_/.test(list[0].id));
    const editBtn = d.querySelector('[data-act=edit]');
    ok('crud: Edit/Delete buttons carry the record id', editBtn && editBtn.getAttribute('data-id') === list[0].id);
    ok('crud: text is escaped in the table', !d.querySelector('#crudListWrap b') && /Test Op <b>x<\/b>/.test(d.getElementById('crudListWrap').textContent));
    editBtn.click(); await sleep(20);
    ok('crud: edit opens the form with the saved value', d.querySelector('#crudForm [name=name]').value === 'Test Op <b>x</b>');
    d.getElementById('crudCancel').click(); await sleep(20);
    d.querySelector('[data-act=delete]').click(); await sleep(20);
    ok('crud: delete removes the record', w.CP.storage.load('team', []).length === 0);
  }

  // ---------- Document library ----------
  { const r = await boot({ root: ROOT, seed: ACCEPTED }); const w = r.window, d = r.doc;
    w.CP.storage.save('eventDocuments', [
      { id: 'id_1', title: 'good', dataUrl: 'data:application/pdf;base64,JVBERi0xLjQ=', fileName: 'a.pdf' },
      { id: 'id_2', title: 'svg', dataUrl: 'data:image/svg+xml;base64,PHN2Zz48L3N2Zz4=', fileName: 'b.svg' },
      { id: 'id_3', title: 'js', dataUrl: 'javascript:alert(1)', fileName: 'c' },
      { id: 'id_4', title: 'attr', dataUrl: 'data:image/png;base64,AAAA" onclick="x', fileName: 'd' }]);
    await goto(r, 'eventSecurity');
    const links = [...d.querySelectorAll('a[download]')];
    ok('docs: only well-formed PDF/PNG/JPEG/GIF/WebP data URLs get a View link (svg, javascript:, attribute-break all refused)', links.length === 1 && links[0].getAttribute('href').startsWith('data:application/pdf'), 'links=' + links.length);
    ok('docs: external links use noopener noreferrer', links.every(a => /noopener/.test(a.rel) && /noreferrer/.test(a.rel)));
    // upload size guard + type guard
    const div = d.createElement('div'); d.body.appendChild(div); w.CP.ui.docLibrary(div, { storageKey: 'zz' });
    div.querySelector('#docAddBtn').click(); await sleep(20);
    const f = div.querySelector('#docForm'); f.querySelector('[name=title]').value = 'big'; /* jsdom lacks the browser's named-control access on forms */ const named = (fm) => ['title','file','notes'].forEach(n => Object.defineProperty(fm, n, { value: fm.querySelector('[name=' + n + ']'), configurable: true })); named(f);
    const big = new w.File([new Uint8Array(2 * 1024 * 1024)], 'big.pdf', { type: 'application/pdf' });
    Object.defineProperty(f.querySelector('[name=file]'), 'files', { value: [big], configurable: true });
    f.dispatchEvent(new w.Event('submit', { cancelable: true })); await sleep(30);
    ok('docs: 2 MB upload refused with a clear message (limit 1.5 MB)', r.alerts.some(a => /too large/.test(a)) && w.CP.storage.load('zz', []).length === 0);
    div.querySelector('#docAddBtn') && null;
    const f2 = div.querySelector('#docForm'); f2.querySelector('[name=title]').value = 'ok'; named(f2);
    const png = new w.File([Buffer.from('89504e470d0a1a0a', 'hex')], 'p.png', { type: 'image/png' });
    Object.defineProperty(f2.querySelector('[name=file]'), 'files', { value: [png], configurable: true });
    f2.dispatchEvent(new w.Event('submit', { cancelable: true })); await sleep(120);
    ok('docs: a small PNG uploads and is stored as a safe data URL', w.CP.storage.load('zz', []).length === 1 && w.CP.ui.safeDataUrl(w.CP.storage.load('zz', [])[0].dataUrl) !== '');
    div.querySelector('#docAddBtn') && div.querySelector('#docAddBtn').click(); await sleep(20);
    ok('docs: file picker limited to PDF/PNG/JPEG/GIF/WebP (no SVG/HEIC/TIFF)', /accept="application\/pdf,image\/png,image\/jpeg,image\/gif,image\/webp"/.test(div.innerHTML), div.innerHTML.slice(0, 200));
  }

  // ---------- URL helpers ----------
  { const r = await boot({ root: ROOT, seed: ACCEPTED }); const U = r.window.CP.ui;
    const good = ['https://www.google.com/maps/search/?api=1&query=10%20Downing%20St', 'https://what3words.com/filled.count.soap', 'https://www.gov.uk/foreign-travel-advice/france'];
    const badU = ['javascript:alert(1)', 'http://insecure.example', 'https://x.com/"onmouseover="1', 'data:text/html,hi', ' https://x.com', 'https://x.com/a b', '//evil.com', ''];
    const U2 = r.window.CP.ui; const built = [U2.mapsLink("St Mary's Road, O'Connell St (rear) ~ #5!"), U2.mapsDirLink("A's Yard", "B (x) & Co"), U2.w3wLink('///filled.count.soap'), U2.govukTravelAdviceUrl('Ivory Coast'), U2.govukSearchUrl("Côte d'Ivoire")];
    ok("safeUrl: every URL the app itself builds passes, including addresses with apostrophes/brackets/unicode", built.every(u => !u || U2.safeUrl(u) === u), built.map(u => U2.safeUrl(u) ? 'ok' : 'REJECTED ' + u).join(' ; '));
    ok('safeUrl: allows the app\'s own https links', good.every(u => U.safeUrl(u) === u), good.map(u => U.safeUrl(u) ? 1 : 0).join(''));
    ok('safeUrl: refuses javascript:, http:, data:, quote/space injection, protocol-relative, empty', badU.every(u => U.safeUrl(u) === ''), badU.map(u => U.safeUrl(u) ? 'LEAK:' + u : '').join(' '));
    ok('safeId: accepts generated ids, refuses attribute-break ids', U.safeId('id_lq3x_ab12cd') && !U.safeId('a"b') && !U.safeId('') && !U.safeId('x'.repeat(200)));
  }

  // ---------- UK Laws ----------
  { const r = await boot({ root: ROOT, seed: ACCEPTED }); const d = r.doc; await goto(r, 'uklaws');
    const t = d.getElementById('content').textContent;
    ok('laws: misleading "pre-emptive force is not protected" wording removed', !/Excessive or pre-emptive force is not protected/.test(t));
    ok('laws: force card now states no need to wait to be struck, cites s.76 CJIA 2008 and Beckford', /do not have to wait to be attacked/.test(t) && /s\.76/.test(t) && /Beckford/.test(t));
    ok('laws: data protection card covers Article 9 special-category health data', /Article 9/.test(t) && /special category/.test(t));
    ok('laws: weapons card (PAVA/CS, PCA 1953, s.139 CJA 1988) added', /PAVA/.test(t) && /Prevention of Crime Act 1953/.test(t) && /s\.139/.test(t));
    ok('laws: Martyn\'s Law card is dated-accurate (not yet in force, 24-month implementation)', /NOT yet in force/.test(t) && /24 months/.test(t) && !/still being finalised/.test(t));
    const links = [...d.querySelectorAll('.law-item a')];
    ok('laws: every card has a source link, https + noopener', links.length === 10 /* 9 law cards + the Privacy link in the terms record */ && links.every(a => /^https:\/\//.test(a.href) && /noopener/.test(a.rel)), 'links=' + links.length);
    ok('laws: every card shows a "wording last edited" date', (t.match(/Wording last edited: 20 September 2026/g) || []).length === 9);
  }


  // ---------- External link buttons still work (regression check for the URL allow-list) ----------
  { const r = await boot({ root: ROOT, seed: ACCEPTED }); const w = r.window, d = r.doc;
    w.CP.storage.save('advanceVenues', [{ id: 'id_v1', venueName: "St Mary's Hall", address: "St Mary's Road, O'Connell Street (rear)", w3w: '///filled.count.soap', eventDate: '2026-10-01' }]);
    await goto(r, 'advance');
    const a = [...d.querySelectorAll('#content a.btn')];
    const map = a.find(x => x.textContent === 'Map'), w3 = a.find(x => x.textContent === 'what3words');
    ok('links: Map + what3words buttons render for an address containing apostrophes/brackets', !!map && !!w3 && /^https:\/\/www\.google\.com\/maps\/search\//.test(map.href) && /what3words\.com\/filled\.count\.soap$/.test(w3.href), a.map(x => x.textContent + '=' + x.getAttribute('href')).join(' | '));
    ok('links: external buttons carry target=_blank, rel=noopener noreferrer, and a "text is sent to that site" tooltip', map && map.target === '_blank' && /noopener/.test(map.rel) && /noreferrer/.test(map.rel) && /sent to that site/.test(map.title));
    w.CP.storage.save('travelDocs', [{ id: 'id_t1', country: "Côte d'Ivoire" }]);
    await goto(r, 'travelDocs');
    const g = [...d.querySelectorAll('#content a.btn')].map(x => x.getAttribute('href'));
    ok('links: GOV.UK travel-advice buttons render (direct + search fallback)', g.length >= 2 && g.every(h => /^https:\/\/www\.gov\.uk\//.test(h)), g.join(' | '));
    ok('no runtime errors were logged across the whole root suite', r.errors.length === 0, r.errors.join('|'));
  }

  // ---------- Import (root) ----------
  { const r = await boot({ root: ROOT, seed: ACCEPTED }); const w = r.window;
    const run = obj => w.CP.storage.importParsed(obj);
    let threw = false; try { run([1, 2]); } catch (e) { threw = true; }
    ok('import: a JSON array is rejected as "not a backup"', threw);
    const s1 = run({ team: 'x'.repeat(600000) });
    ok('import: oversized string value skipped, not stored', s1.skipped === 1 && w.localStorage.getItem('cpapp_team') === null);
    const deep = {}; let cur = deep; for (let i = 0; i < 15; i++) { cur.a = {}; cur = cur.a; }
    const s2 = run({ team: deep });
    ok('import: absurdly nested value skipped', s2.skipped === 1);
    const s3 = run({ operations: [{ id: 'op_id_aaa_bbb', name: 'N'.repeat(1000), createdDate: 'not-a-date' }], currentOperationId: 'nope' });
    const ops = w.CP.storage.getOperations();
    ok('import: operation registry entries validated (id format, name length, date)', ops.length === 1 && ops[0].name.length === 200 && /^\d{4}-\d{2}-\d{2}$/.test(ops[0].createdDate) && s3.skipped === 1);
    ok('import: current operation always points at an operation that exists', ops.some(o => o.id === w.CP.storage.getCurrentOperationId()));
  }

  // ---------- Service worker ----------
  for (const [label, dir] of [['root', ROOT], ['beta', ROOT + '/beta']]) {
    const src = fs.readFileSync(path.join(dir, 'sw.js'), 'utf8');
    const listeners = {}; let deleted = [];
    const sandbox = { self: { addEventListener: (n, f) => { listeners[n] = f; }, skipWaiting: () => Promise.resolve(), clients: { claim: () => Promise.resolve() } },
      caches: { keys: () => Promise.resolve(['cp-ops-v2', 'cp-ops-v5', 'cp-ops-v6', 'cp-ops-beta-v3', 'saferoute-v19']), delete: k => { deleted.push(k); return Promise.resolve(true); }, open: () => Promise.resolve({}) }, fetch: () => {}, Promise, console };
    vm.createContext(sandbox); vm.runInContext(src, sandbox);
    let p; listeners.activate({ waitUntil: x => { p = x; } }); await p;
    const name = vm.runInContext('CACHE_NAME', sandbox);
    ok(`sw (${label}): cache "${name}" cleanup never touches SafeRoute's cache or the other build's`, !deleted.includes('saferoute-v19') && (label === 'root' ? !deleted.includes('cp-ops-beta-v3') : !deleted.includes('cp-ops-v6') && !deleted.includes('cp-ops-v5')), 'deleted=' + deleted.join(','));
    const urls = vm.runInContext('PRECACHE_URLS', sandbox);
    const missing = urls.filter(u => u !== './' && !fs.existsSync(path.join(dir, u)));
    ok(`sw (${label}): every precached file exists on disk (a missing one makes the whole install fail)`, missing.length === 0, 'missing=' + missing.join(','));
    const scripts = [...fs.readFileSync(path.join(dir, 'index.html'), 'utf8').matchAll(/<script src="([^"]+)"/g)].map(m => './' + m[1]);
    const notCached = scripts.filter(s => !urls.includes(s));
    ok(`sw (${label}): every script the page loads is precached`, notCached.length === 0, 'notCached=' + notCached.join(','));
  }

  // ---------- CSP / static ----------
  for (const page of ['index.html', 'beta/index.html', 'privacy.html']) {
    const html = fs.readFileSync(path.join(ROOT, page), 'utf8');
    const m = html.match(/http-equiv="Content-Security-Policy" content="([^"]+)"/);
    ok(`csp (${page}): present, no unsafe-inline scripts, no unsafe-eval, no remote sources`, !!m && !/script-src[^;]*unsafe/.test(m[1]) && !/https?:/.test(m[1]) && /default-src 'none'/.test(m[1]), m && m[1]);
    ok(`html (${page}): no inline <script> and no on*= handlers`, !/<script(?![^>]*\ssrc=)[^>]*>/.test(html) && !/\son\w+\s*=/.test(html));
  }
  { const html = fs.readFileSync(path.join(ROOT, 'privacy.html'), 'utf8');
    ok('privacy: names RD Anzen Ltd + company number + contact, covers on-device storage, hosting, link-outs, ICO', ['RD Anzen Ltd', '08957578', 'Rick@RDAnzen.co.uk', 'not encrypted', 'GitHub Pages', 'what3words', 'ico.org.uk', 'special category'].every(t => html.includes(t)));
    const foot = fs.readFileSync(path.join(ROOT, 'index.html'), 'utf8');
    ok('footer: company name + number + Privacy Policy link + contact email', /RD Anzen Ltd \(company no\. 08957578\)/.test(foot) && /privacy\.html/.test(foot) && /Rick@RDAnzen\.co\.uk/.test(foot));
    ok('beta footer: fixed "RDanzen Ltd" misspelling', !/RDanzen Ltd/.test(fs.readFileSync(path.join(ROOT, 'beta/index.html'), 'utf8')));
  }
  console.log(`\nROOT RESULT: ${pass} passed, ${fail} failed`); if (fail) console.log('FAILED: ' + failures.join(' | '));
  process.exit(fail ? 1 : 0);
})().catch(e => { console.error('HARNESS ERROR', e); process.exit(2); });
