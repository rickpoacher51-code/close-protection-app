window.CP = window.CP || {};
CP.lock = {};

// Simple, distinct, easy-to-write words for system-generated recovery phrases.
var CP_LOCK_WORDS = [
  'able', 'acorn', 'amber', 'anchor', 'apple', 'arch', 'arrow', 'ash', 'aspen', 'autumn',
  'badge', 'banner', 'barn', 'basin', 'beacon', 'bear', 'birch', 'blade', 'blaze', 'bloom',
  'blue', 'boat', 'bolt', 'bramble', 'brave', 'breeze', 'bridge', 'brook', 'cabin', 'camp',
  'canyon', 'cedar', 'chalk', 'charm', 'cliff', 'cloud', 'clover', 'coast', 'comet', 'compass',
  'copper', 'coral', 'cove', 'crane', 'creek', 'crest', 'crimson', 'crown', 'cypress', 'dawn',
  'deer', 'delta', 'desert', 'dove', 'drift', 'eagle', 'ember', 'falcon', 'feather', 'fern',
  'field', 'finch', 'fjord', 'flame', 'flint', 'forest', 'fox', 'garnet', 'glacier', 'glade',
  'gold', 'granite', 'grove', 'gull', 'harbor', 'hawk', 'hazel', 'hearth', 'hickory', 'holly',
  'honey', 'horizon', 'indigo', 'ivory', 'ivy', 'jade', 'juniper', 'kestrel', 'lagoon', 'lake',
  'lantern', 'lark', 'laurel', 'leaf', 'ledge', 'lily', 'linden', 'lotus', 'lynx', 'maple',
  'marble', 'marsh', 'meadow', 'mesa', 'mint', 'mist', 'moor', 'moss', 'mountain', 'myrtle',
  'north', 'oak', 'oasis', 'oat', 'ocean', 'olive', 'onyx', 'opal', 'orbit', 'osprey',
  'otter', 'owl', 'palm', 'path', 'peak', 'pear', 'pebble', 'pepper', 'pine', 'plum',
  'pond', 'poplar', 'prairie', 'quail', 'quartz', 'quill', 'rain', 'raven', 'reed', 'reef',
  'ridge', 'river', 'robin', 'rock', 'rose', 'rowan', 'ruby', 'sage', 'sail', 'sand',
  'sapphire', 'shale', 'shore', 'sky', 'slate', 'snow', 'sparrow', 'spring', 'spruce', 'star',
  'stone', 'storm', 'stream', 'summit', 'sunset', 'swan', 'sycamore', 'teal', 'thistle', 'thorn',
  'thunder', 'tide', 'timber', 'topaz', 'trail', 'tundra', 'valley', 'velvet', 'vine', 'violet',
  'vista', 'walnut', 'warbler', 'water', 'wave', 'wheat', 'whisper', 'willow', 'wind', 'wing',
  'winter', 'wolf', 'wood', 'wren', 'zephyr'
];

var CP_RECOVERY_WORD_COUNT = 6;

function cpRandomInt(max) {
  var arr = new Uint32Array(1);
  crypto.getRandomValues(arr);
  return arr[0] % max;
}

function cpRandomWords(count) {
  var pool = CP_LOCK_WORDS.slice();
  var chosen = [];
  for (var i = 0; i < count; i++) {
    var idx = cpRandomInt(pool.length);
    chosen.push(pool[idx]);
    pool.splice(idx, 1);
  }
  return chosen;
}

function cpRandomSalt() {
  var arr = new Uint8Array(16);
  crypto.getRandomValues(arr);
  return Array.from(arr).map(function (b) { return b.toString(16).padStart(2, '0'); }).join('');
}

function cpSha256Hex(str) {
  var enc = new TextEncoder().encode(str);
  return crypto.subtle.digest('SHA-256', enc).then(function (buf) {
    return Array.from(new Uint8Array(buf)).map(function (b) { return b.toString(16).padStart(2, '0'); }).join('');
  });
}

// PBKDF2-SHA256 (600,000 iterations, OWASP 2023 guidance) replaces the old single SHA-256 pass.
// A 6-digit PIN is still only 1,000,000 possibilities, so this slows guessing down - it does not
// make the PIN strong. The lock is a screen lock, not encryption (the settings panel says so).
var CP_PBKDF2_ITER = 600000;
var CP_RELOCK_AFTER_MS = 5 * 60 * 1000;   // re-lock after 5 minutes in the background
var CP_LOCK_MAX_FREE_TRIES = 5;

function cpPbkdf2Hex(secret, saltHex, iterations) {
  var enc = new TextEncoder();
  return crypto.subtle.importKey('raw', enc.encode(secret), 'PBKDF2', false, ['deriveBits']).then(function (km) {
    return crypto.subtle.deriveBits({ name: 'PBKDF2', salt: enc.encode(saltHex), iterations: iterations, hash: 'SHA-256' }, km, 256);
  }).then(function (bits) {
    return Array.from(new Uint8Array(bits)).map(function (b) { return b.toString(16).padStart(2, '0'); }).join('');
  });
}

// Hash a PIN/phrase the way this config was created (legacy configs used one SHA-256 pass).
function cpHashSecret(cfg, kind, value, forceNew) {
  var kdf = forceNew ? 'pbkdf2-sha256' : (kind === 'pin' ? cfg.pinKdf : cfg.recoveryKdf);
  if (kdf === 'pbkdf2-sha256') return cpPbkdf2Hex(kind + ':' + value, cfg.salt, cfg.iter || CP_PBKDF2_ITER);
  return cpSha256Hex(cfg.salt + ':' + kind + ':' + value);
}

function cpNormalizePhrase(str) {
  return String(str || '').trim().toLowerCase().replace(/\s+/g, ' ');
}

// --- Config ---

CP.lock.getConfig = function () { return CP.storage.loadGlobal('appLock', null); };
CP.lock.isEnabled = function () { return !!CP.lock.getConfig(); };

// --- Guess limiting -----------------------------------------------------------------
// After 5 wrong tries the lock backs off (30s, 60s, 2m ... capped at 15 min). This only slows down
// someone using the normal screen; anyone who can run code on the device can clear it.

CP.lock.lockedMs = function () {
  var st = CP.storage.loadGlobal('lockAttempts', null);
  return st && st.lockedUntil ? Math.max(0, st.lockedUntil - Date.now()) : 0;
};

CP.lock.recordFailure = function () {
  var st = CP.storage.loadGlobal('lockAttempts', null) || { count: 0, lockedUntil: 0 };
  st.count = (st.count || 0) + 1;
  if (st.count >= CP_LOCK_MAX_FREE_TRIES) {
    var delay = Math.min(15 * 60 * 1000, 30000 * Math.pow(2, st.count - CP_LOCK_MAX_FREE_TRIES));
    st.lockedUntil = Date.now() + delay;
  }
  CP.storage.saveGlobal('lockAttempts', st);
};

CP.lock.recordSuccess = function () { CP.storage.removeGlobal('lockAttempts'); };

function cpLockedMessage(ms) {
  var secs = Math.ceil(ms / 1000);
  return 'Too many attempts. Try again in ' + (secs >= 120 ? Math.ceil(secs / 60) + ' minutes' : secs + ' seconds') + '.';
}

// cb(ok, info) - info.lockedMs is set when the attempt was refused because of back-off.
CP.lock.verifyPin = function (pin, cb) {
  var cfg = CP.lock.getConfig();
  if (!cfg) { cb(true); return; }
  var wait = CP.lock.lockedMs();
  if (wait > 0) { cb(false, { lockedMs: wait }); return; }
  cpHashSecret(cfg, 'pin', pin).then(function (hash) {
    if (hash !== cfg.pinHash) { CP.lock.recordFailure(); cb(false, { lockedMs: CP.lock.lockedMs() }); return; }
    CP.lock.recordSuccess();
    if (cfg.pinKdf !== 'pbkdf2-sha256') {
      // Upgrade an old single-SHA-256 PIN hash in place now that we have the PIN.
      cfg.iter = CP_PBKDF2_ITER;
      cpHashSecret(cfg, 'pin', pin, true).then(function (newHash) {
        cfg.pinHash = newHash;
        cfg.pinKdf = 'pbkdf2-sha256';
        CP.storage.saveGlobal('appLock', cfg);
        cb(true);
      }).catch(function () { cb(true); });
      return;
    }
    cb(true);
  });
};

CP.lock.verifyRecoveryPhrase = function (phrase, cb) {
  var cfg = CP.lock.getConfig();
  if (!cfg) { cb(true); return; }
  var wait = CP.lock.lockedMs();
  if (wait > 0) { cb(false, { lockedMs: wait }); return; }
  cpHashSecret(cfg, 'phrase', cpNormalizePhrase(phrase)).then(function (hash) {
    if (hash !== cfg.recoveryHash) { CP.lock.recordFailure(); cb(false, { lockedMs: CP.lock.lockedMs() }); return; }
    CP.lock.recordSuccess();
    cb(true);
  });
};

// Generates a fresh salt + recovery phrase, hashes everything, saves config.
// cb(recoveryWords) is called with the plaintext words so the caller can display them once.
CP.lock.setNewPin = function (pin, cb) {
  var salt = cpRandomSalt();
  var words = cpRandomWords(CP_RECOVERY_WORD_COUNT);
  var phrase = words.join(' ');
  var cfg = { salt: salt, iter: CP_PBKDF2_ITER };
  Promise.all([
    cpHashSecret(cfg, 'pin', pin, true),
    cpHashSecret(cfg, 'phrase', cpNormalizePhrase(phrase), true)
  ]).then(function (results) {
    CP.storage.saveGlobal('appLock', {
      salt: salt, iter: CP_PBKDF2_ITER, pinKdf: 'pbkdf2-sha256', recoveryKdf: 'pbkdf2-sha256',
      pinHash: results[0], recoveryHash: results[1], updatedDate: new Date().toISOString().slice(0, 10)
    });
    CP.lock.recordSuccess();
    cb(words);
  });
};

CP.lock.disable = function () { CP.storage.removeGlobal('appLock'); CP.storage.removeGlobal('lockAttempts'); };

// Re-lock when the app has been in the background for a while (a phone left unattended).
CP.lock.watchBackground = function () {
  var hiddenAt = null;
  document.addEventListener('visibilitychange', function () {
    if (document.visibilityState === 'hidden') { hiddenAt = Date.now(); return; }
    if (hiddenAt !== null && Date.now() - hiddenAt >= CP_RELOCK_AFTER_MS &&
        CP.lock.isEnabled() && !document.getElementById('lockOverlay')) {
      CP.lock.checkAndRun(function () {});
    }
    hiddenAt = null;
  });
};

function cpIsValidPin(pin) { return /^\d{6}$/.test(pin); }

// --- Startup lock screen (blocks the app until unlocked; only shown on a fresh page load) ---

CP.lock.checkAndRun = function (onUnlocked) {
  if (!CP.lock.isEnabled()) { onUnlocked(); return; }

  var overlay = document.createElement('div');
  overlay.id = 'lockOverlay';
  overlay.className = 'lock-overlay';
  document.body.appendChild(overlay);

  var mode = 'pin'; // 'pin' | 'recovery' | 'newpin'

  function unlock() {
    overlay.remove();
    onUnlocked();
  }

  function draw() {
    if (mode === 'pin') {
      overlay.innerHTML =
        '<div class="lock-card">' +
        '<div class="lock-emblem"><img src="icons/icon-192.png" alt=""></div>' +
        '<h2>Enter PIN</h2>' +
        '<form id="lockPinForm">' +
        '<input type="password" inputmode="numeric" pattern="[0-9]*" maxlength="6" autocomplete="off" id="lockPinInput" placeholder="6-digit PIN">' +
        '<div class="lock-error" id="lockError"></div>' +
        '<button type="submit" class="btn btn-primary">Unlock</button>' +
        '</form>' +
        '<a href="#" id="lockForgotLink">Forgotten PIN?</a>' +
        '</div>';
      overlay.querySelector('#lockPinInput').focus();
      overlay.querySelector('#lockPinForm').addEventListener('submit', function (e) {
        e.preventDefault();
        var pin = overlay.querySelector('#lockPinInput').value;
        CP.lock.verifyPin(pin, function (ok, info) {
          if (ok) { unlock(); return; }
          overlay.querySelector('#lockError').textContent =
            (info && info.lockedMs) ? cpLockedMessage(info.lockedMs) : 'Incorrect PIN.';
          overlay.querySelector('#lockPinInput').value = '';
          overlay.querySelector('#lockPinInput').focus();
        });
      });
      overlay.querySelector('#lockForgotLink').addEventListener('click', function (e) {
        e.preventDefault();
        mode = 'recovery';
        draw();
      });
    } else if (mode === 'recovery') {
      overlay.innerHTML =
        '<div class="lock-card">' +
        '<h2>Recovery Phrase</h2>' +
        '<p class="hint">Enter the recovery phrase you were shown when the PIN was set up.</p>' +
        '<form id="lockRecoveryForm">' +
        '<input type="text" autocomplete="off" id="lockRecoveryInput" placeholder="word word word word word word">' +
        '<div class="lock-error" id="lockError"></div>' +
        '<button type="submit" class="btn btn-primary">Continue</button>' +
        '</form>' +
        '<a href="#" id="lockBackLink">Back to PIN entry</a>' +
        '</div>';
      overlay.querySelector('#lockRecoveryInput').focus();
      overlay.querySelector('#lockRecoveryForm').addEventListener('submit', function (e) {
        e.preventDefault();
        var phrase = overlay.querySelector('#lockRecoveryInput').value;
        CP.lock.verifyRecoveryPhrase(phrase, function (ok, info) {
          if (ok) { mode = 'newpin'; draw(); return; }
          overlay.querySelector('#lockError').textContent =
            (info && info.lockedMs) ? cpLockedMessage(info.lockedMs) : 'That recovery phrase doesn’t match.';
        });
      });
      overlay.querySelector('#lockBackLink').addEventListener('click', function (e) {
        e.preventDefault();
        mode = 'pin';
        draw();
      });
    } else if (mode === 'newpin') {
      overlay.innerHTML =
        '<div class="lock-card">' +
        '<h2>Set a New PIN</h2>' +
        '<p class="hint">Recovery verified. Choose a new 6-digit PIN — you’ll get a new recovery phrase too.</p>' +
        '<form id="lockNewPinForm">' +
        '<input type="password" inputmode="numeric" pattern="[0-9]*" maxlength="6" autocomplete="off" id="lockNewPin1" placeholder="New 6-digit PIN">' +
        '<input type="password" inputmode="numeric" pattern="[0-9]*" maxlength="6" autocomplete="off" id="lockNewPin2" placeholder="Confirm new PIN">' +
        '<div class="lock-error" id="lockError"></div>' +
        '<button type="submit" class="btn btn-primary">Save New PIN</button>' +
        '</form>' +
        '</div>';
      overlay.querySelector('#lockNewPinForm').addEventListener('submit', function (e) {
        e.preventDefault();
        var p1 = overlay.querySelector('#lockNewPin1').value;
        var p2 = overlay.querySelector('#lockNewPin2').value;
        if (!cpIsValidPin(p1)) { overlay.querySelector('#lockError').textContent = 'PIN must be exactly 6 digits.'; return; }
        if (p1 !== p2) { overlay.querySelector('#lockError').textContent = 'PINs don’t match.'; return; }
        CP.lock.setNewPin(p1, function (words) {
          mode = 'showphrase';
          renderPhraseAck(words);
        });
      });
    }
  }

  function renderPhraseAck(words) {
    overlay.innerHTML =
      '<div class="lock-card">' +
      '<h2>Your New Recovery Phrase</h2>' +
      '<p class="hint">Write this down somewhere safe, outside this app. It won’t be shown again.</p>' +
      '<div class="lock-phrase">' + words.join(' ') + '</div>' +
      '<label class="lock-ack"><input type="checkbox" id="lockAckBox"> I’ve saved this phrase somewhere safe</label>' +
      '<button type="button" class="btn btn-primary" id="lockAckContinue" disabled>Continue</button>' +
      '</div>';
    var box = overlay.querySelector('#lockAckBox');
    var btn = overlay.querySelector('#lockAckContinue');
    box.addEventListener('change', function () { btn.disabled = !box.checked; });
    btn.addEventListener('click', function () { unlock(); });
  }

  draw();
};

// --- Dashboard settings panel: view status, set up / change / disable the PIN ---

CP.lock.renderSettings = function (container) {
  var step = { mode: CP.lock.isEnabled() ? 'status' : 'status' };
  var pendingWords = null;

  function draw() {
    var enabled = CP.lock.isEnabled();

    if (step.mode === 'status') {
      container.innerHTML = enabled
        ? '<p class="hint">App lock is <strong>ON</strong>. A 6-digit PIN is required when the app is opened, and again after it has been in the background for 5 minutes. ' +
          'This is a screen lock: the data stored on this device is <strong>not encrypted</strong>.</p>' +
          '<div class="form-actions"><button class="btn btn-small" id="lockChangeBtn">Change PIN</button>' +
          '<button class="btn btn-small btn-danger" id="lockDisableBtn">Disable Lock</button></div>'
        : '<p class="hint">App lock is <strong>OFF</strong>. Set a 6-digit PIN so the app can’t be opened without it. ' +
          'This deters casual/shoulder-surfed access on this device — it isn’t protection against someone with the device and technical tools, and the data stored on this device is not encrypted.</p>' +
          '<div class="form-actions"><button class="btn btn-primary btn-small" id="lockSetupBtn">Set Up PIN</button></div>';

      var setupBtn = container.querySelector('#lockSetupBtn');
      if (setupBtn) setupBtn.addEventListener('click', function () { step.mode = 'new-pin'; step.afterVerify = false; draw(); });

      var changeBtn = container.querySelector('#lockChangeBtn');
      if (changeBtn) changeBtn.addEventListener('click', function () { step.mode = 'verify'; step.next = 'new-pin'; draw(); });

      var disableBtn = container.querySelector('#lockDisableBtn');
      if (disableBtn) disableBtn.addEventListener('click', function () { step.mode = 'verify'; step.next = 'disable'; draw(); });
    }

    else if (step.mode === 'verify') {
      container.innerHTML =
        '<form id="lockVerifyForm" class="inline-add-form">' +
        '<input type="password" inputmode="numeric" pattern="[0-9]*" maxlength="6" autocomplete="off" id="lockVerifyInput" placeholder="Enter current PIN">' +
        '<button type="submit" class="btn btn-small btn-primary">Confirm</button>' +
        '<button type="button" class="btn btn-small" id="lockVerifyCancel">Cancel</button>' +
        '</form><div class="lock-error" id="lockSettingsError"></div>';
      container.querySelector('#lockVerifyCancel').addEventListener('click', function () { step.mode = 'status'; draw(); });
      container.querySelector('#lockVerifyForm').addEventListener('submit', function (e) {
        e.preventDefault();
        var pin = container.querySelector('#lockVerifyInput').value;
        CP.lock.verifyPin(pin, function (ok, info) {
          if (!ok) {
            container.querySelector('#lockSettingsError').textContent =
              (info && info.lockedMs) ? cpLockedMessage(info.lockedMs) : 'Incorrect PIN.';
            return;
          }
          if (step.next === 'disable') {
            CP.lock.disable();
            step.mode = 'status';
            draw();
          } else {
            step.mode = 'new-pin';
            draw();
          }
        });
      });
    }

    else if (step.mode === 'new-pin') {
      container.innerHTML =
        '<form id="lockNewPinForm" class="crud-form">' +
        '<label class="field"><span>New 6-digit PIN</span><input type="password" inputmode="numeric" pattern="[0-9]*" maxlength="6" autocomplete="off" id="lockSetupPin1"></label>' +
        '<label class="field"><span>Confirm New PIN</span><input type="password" inputmode="numeric" pattern="[0-9]*" maxlength="6" autocomplete="off" id="lockSetupPin2"></label>' +
        '<div class="lock-error" id="lockSettingsError"></div>' +
        '<div class="form-actions"><button type="submit" class="btn btn-primary">Save PIN</button>' +
        '<button type="button" class="btn" id="lockNewPinCancel">Cancel</button></div>' +
        '</form>';
      container.querySelector('#lockNewPinCancel').addEventListener('click', function () { step.mode = 'status'; draw(); });
      container.querySelector('#lockNewPinForm').addEventListener('submit', function (e) {
        e.preventDefault();
        var p1 = container.querySelector('#lockSetupPin1').value;
        var p2 = container.querySelector('#lockSetupPin2').value;
        var err = container.querySelector('#lockSettingsError');
        if (!cpIsValidPin(p1)) { err.textContent = 'PIN must be exactly 6 digits.'; return; }
        if (p1 !== p2) { err.textContent = 'PINs don’t match.'; return; }
        CP.lock.setNewPin(p1, function (words) {
          pendingWords = words;
          step.mode = 'show-phrase';
          draw();
        });
      });
    }

    else if (step.mode === 'show-phrase') {
      container.innerHTML =
        '<p class="hint">Write this recovery phrase down somewhere safe, outside this app. It won’t be shown again.</p>' +
        '<div class="lock-phrase">' + pendingWords.join(' ') + '</div>' +
        '<label class="lock-ack"><input type="checkbox" id="lockSettingsAck"> I’ve saved this phrase somewhere safe</label>' +
        '<div class="form-actions"><button type="button" class="btn btn-primary" id="lockSettingsAckDone" disabled>Done</button></div>';
      var box = container.querySelector('#lockSettingsAck');
      var btn = container.querySelector('#lockSettingsAckDone');
      box.addEventListener('change', function () { btn.disabled = !box.checked; });
      btn.addEventListener('click', function () { pendingWords = null; step.mode = 'status'; draw(); });
    }
  }

  draw();
};
