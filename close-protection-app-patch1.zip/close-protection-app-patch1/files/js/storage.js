window.CP = window.CP || {};

CP.PREFIX = 'cpapp_';
CP.NAV = [];
CP.segments = {};

CP.registerSegment = function (seg) {
  CP.segments[seg.key] = seg;
  CP.NAV.push(seg);
};

// Every data key used anywhere in the app. Used only for the one-time migration
// below, to move a pre-existing (single-operation) install into "Operation 1".
var CP_KNOWN_DATA_KEYS = [
  'opInfo', 'team', 'medicalProfile', 'principalFamily', 'medicalKitChecklist',
  'casevacHospitals', 'medicationLegality', 'routes', 'advanceVenues', 'commsContacts',
  'advanceTasks', 'eventSecurityPlan', 'eventDocuments', 'eventIncidentLog',
  'rstRoster', 'rstPerimeterChecklist', 'rstVisitorLog', 'rstPatrolLog',
  'actionsOnDrills', 'actionsOnSeeded', 'threatRegions', 'safeHavens',
  'extractionPoints', 'travelDocs', 'uklawsNotes'
];

function cpMigrateToOperationsIfNeeded() {
  if (localStorage.getItem(CP.PREFIX + 'operations')) return;

  var id = 'op_' + CP.storage.uid();
  var opInfoRaw = localStorage.getItem(CP.PREFIX + 'opInfo');
  var opInfo = {};
  try { opInfo = opInfoRaw ? JSON.parse(opInfoRaw) : {}; } catch (e) { opInfo = {}; }
  var name = opInfo.operationName || 'Operation 1';

  CP_KNOWN_DATA_KEYS.forEach(function (key) {
    var raw = localStorage.getItem(CP.PREFIX + key);
    if (raw !== null) {
      localStorage.setItem(CP.PREFIX + id + '_' + key, raw);
      localStorage.removeItem(CP.PREFIX + key);
    }
  });

  localStorage.setItem(CP.PREFIX + 'operations', JSON.stringify([
    { id: id, name: name, createdDate: new Date().toISOString().slice(0, 10) }
  ]));
  localStorage.setItem(CP.PREFIX + 'currentOperationId', id);
}

// Every write goes through here so a full/blocked browser store is never silent.
// The thrown error is tagged (cpAlerted) so callers don't show a second alert.
var cpLastStorageAlert = 0;
function cpSafeSetItem(fullKey, str) {
  try {
    localStorage.setItem(fullKey, str);
  } catch (e) {
    var now = Date.now();
    if (now - cpLastStorageAlert > 4000) {
      cpLastStorageAlert = now;
      alert('Could not save: this browser\u2019s storage is full or blocked, so your last change was NOT saved. ' +
        'Export a backup now (Export Data), then free up space by deleting old documents or operations.');
    }
    if (e && typeof e === 'object') e.cpAlerted = true;
    throw e;
  }
}

// --- Import hardening -------------------------------------------------------
// Backup and share files are untrusted input: they can come from anyone. Nothing from a file is
// written to storage unless its key is on the allow-list and its value passes the checks below.

// Never restored from a file: PIN/lock config and the terms-acceptance record are per-device.
var CP_NEVER_IMPORT = ['appLock', 'disclaimerAcceptance', 'lockAttempts', 'lastBackup'];
// Never written into backups either (a backup that carries the PIN hash lets anyone try to crack it offline).
var CP_NEVER_EXPORT = ['appLock', 'disclaimerAcceptance', 'lockAttempts', 'lastBackup'];

var CP_OP_ID_RE = /^op_id_[a-z0-9]+_[a-z0-9]+$/;
var CP_OP_DATA_KEY_RE = /^op_id_[a-z0-9]+_[a-z0-9]+_[A-Za-z0-9]{1,64}$/;
var CP_MAX_STRING = 500000;      // ordinary text fields
var CP_MAX_DATAURL = 4000000;    // uploaded documents (base64)
var CP_BAD_KEYS = ['__proto__', 'constructor', 'prototype'];

function cpImportKeyAllowed(k) {
  if (typeof k !== 'string' || CP_NEVER_IMPORT.indexOf(k) !== -1) return false;
  if (k === 'operations' || k === 'currentOperationId') return true;
  if (CP_KNOWN_DATA_KEYS.indexOf(k) !== -1) return true;   // pre-operations (flat) backups
  return CP_OP_DATA_KEY_RE.test(k);
}

// Returns a cleaned copy of an imported value. Throws if the value is structurally unsafe/oversized.
// stats.sanitized counts individual fixes (bad ids replaced, unsafe attachments dropped).
function cpSanitizeImported(v, depth, stats, fieldName) {
  depth = depth || 0;
  if (depth > 10) throw new Error('nesting too deep');
  if (v === null || typeof v === 'boolean') return v;
  if (typeof v === 'number') { if (!isFinite(v)) throw new Error('bad number'); return v; }
  if (typeof v === 'string') {
    if (fieldName === 'dataUrl') {
      if (v === '') return v;
      if (v.length > CP_MAX_DATAURL || !CP.ui.safeDataUrl(v)) { stats.sanitized++; return ''; }
      return v;
    }
    if (fieldName === 'id') {
      if (!CP.ui.safeId(v)) { stats.sanitized++; return CP.storage.uid(); }
      return v;
    }
    if (v.length > CP_MAX_STRING) throw new Error('string too long');
    return v;
  }
  if (Array.isArray(v)) {
    if (v.length > 20000) throw new Error('array too long');
    return v.map(function (x) { return cpSanitizeImported(x, depth + 1, stats, null); });
  }
  if (typeof v === 'object') {
    var keys = Object.keys(v);
    if (keys.length > 500) throw new Error('object too large');
    var out = {};
    keys.forEach(function (k) {
      if (CP_BAD_KEYS.indexOf(k) !== -1) { stats.sanitized++; return; }
      out[k] = cpSanitizeImported(v[k], depth + 1, stats, k);
    });
    return out;
  }
  throw new Error('unsupported value');
}

// The operation registry gets extra checks: only well-formed entries survive.
function cpCleanOperationsList(list, stats) {
  if (!Array.isArray(list)) throw new Error('operations must be a list');
  var clean = [];
  list.forEach(function (o) {
    if (!o || typeof o !== 'object' || !CP_OP_ID_RE.test(String(o.id || ''))) { stats.sanitized++; return; }
    clean.push({
      id: o.id,
      name: String(o.name || 'Operation').slice(0, 200),
      createdDate: /^\d{4}-\d{2}-\d{2}$/.test(String(o.createdDate || '')) ? o.createdDate : new Date().toISOString().slice(0, 10)
    });
  });
  return clean;
}

CP.storage = {
  load: function (key, fallback) {
    try {
      var raw = localStorage.getItem(CP.PREFIX + CP.storage.getCurrentOperationId() + '_' + key);
      if (raw === null) return fallback;
      return JSON.parse(raw);
    } catch (e) {
      console.error('CP storage load failed for', key, e);
      return fallback;
    }
  },

  save: function (key, value) {
    cpSafeSetItem(CP.PREFIX + CP.storage.getCurrentOperationId() + '_' + key, JSON.stringify(value));
  },

  uid: function () {
    return 'id_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 8);
  },

  // --- Global (non-operation-scoped) storage, for things like app lock config
  // that must apply regardless of which operation is currently open ---

  loadGlobal: function (key, fallback) {
    try {
      var raw = localStorage.getItem(CP.PREFIX + key);
      if (raw === null) return fallback;
      return JSON.parse(raw);
    } catch (e) {
      return fallback;
    }
  },

  saveGlobal: function (key, value) {
    cpSafeSetItem(CP.PREFIX + key, JSON.stringify(value));
  },

  removeGlobal: function (key) {
    localStorage.removeItem(CP.PREFIX + key);
  },

  // --- Operations (separate "pages" of data you can switch between) ---

  getOperations: function () {
    try {
      return JSON.parse(localStorage.getItem(CP.PREFIX + 'operations')) || [];
    } catch (e) {
      return [];
    }
  },

  getCurrentOperationId: function () {
    return localStorage.getItem(CP.PREFIX + 'currentOperationId');
  },

  setCurrentOperationId: function (id) {
    localStorage.setItem(CP.PREFIX + 'currentOperationId', id);
  },

  createOperation: function (name) {
    var ops = CP.storage.getOperations();
    var id = 'op_' + CP.storage.uid();
    ops.push({ id: id, name: name || ('Operation ' + (ops.length + 1)), createdDate: new Date().toISOString().slice(0, 10) });
    localStorage.setItem(CP.PREFIX + 'operations', JSON.stringify(ops));
    return id;
  },

  renameOperation: function (id, name) {
    var ops = CP.storage.getOperations().map(function (o) {
      return o.id === id ? Object.assign({}, o, { name: name }) : o;
    });
    localStorage.setItem(CP.PREFIX + 'operations', JSON.stringify(ops));
  },

  // Returns false if this was the only remaining operation (delete refused).
  deleteOperation: function (id) {
    var ops = CP.storage.getOperations();
    if (ops.length <= 1) return false;
    ops = ops.filter(function (o) { return o.id !== id; });
    localStorage.setItem(CP.PREFIX + 'operations', JSON.stringify(ops));

    var opPrefix = CP.PREFIX + id + '_';
    var toRemove = [];
    for (var i = 0; i < localStorage.length; i++) {
      var k = localStorage.key(i);
      if (k.indexOf(opPrefix) === 0) toRemove.push(k);
    }
    toRemove.forEach(function (k) { localStorage.removeItem(k); });

    if (CP.storage.getCurrentOperationId() === id) {
      CP.storage.setCurrentOperationId(ops[0].id);
    }
    return true;
  },

  // --- Full backup across ALL operations (JSON export/import in the header) ---

  getLastBackup: function () {
    return CP.storage.loadGlobal('lastBackup', null);
  },

  exportAll: function () {
    var out = {};
    for (var i = 0; i < localStorage.length; i++) {
      var k = localStorage.key(i);
      if (k.indexOf(CP.PREFIX) === 0) {
        var short = k.slice(CP.PREFIX.length);
        if (CP_NEVER_EXPORT.indexOf(short) !== -1) continue;   // PIN hashes etc. never leave the device
        try {
          out[short] = JSON.parse(localStorage.getItem(k));
        } catch (e) {
          // skip unreadable entry
        }
      }
    }
    var blob = new Blob([JSON.stringify(out, null, 2)], { type: 'application/json' });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    var stamp = new Date().toISOString().slice(0, 10);
    a.href = url;
    a.download = 'cp-ops-backup-' + stamp + '.json';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    try { CP.storage.saveGlobal('lastBackup', new Date().toISOString()); } catch (e) { /* non-fatal */ }
  },

  // Validates and cleans a parsed backup object, then writes only what passes.
  // Returns { imported, skipped, sanitized }. Throws if the file is not a backup object at all.
  importParsed: function (data) {
    if (!data || typeof data !== 'object' || Array.isArray(data)) throw new Error('not a backup object');
    var result = { imported: 0, skipped: 0, sanitized: 0 };
    var stats = { sanitized: 0 };
    Object.keys(data).forEach(function (k) {
      if (!cpImportKeyAllowed(k)) { result.skipped++; return; }
      try {
        var value;
        if (k === 'operations') value = cpCleanOperationsList(data[k], stats);
        else if (k === 'currentOperationId') {
          if (!CP_OP_ID_RE.test(String(data[k] || ''))) { result.skipped++; return; }
          value = data[k];
        } else value = cpSanitizeImported(data[k], 0, stats, null);
        cpSafeSetItem(CP.PREFIX + k, JSON.stringify(value));
        result.imported++;
      } catch (e) {
        result.skipped++;
      }
    });
    result.sanitized = stats.sanitized;
    // Make sure the "current operation" still points at something that exists.
    var ops = CP.storage.getOperations();
    if (ops.length && !ops.some(function (o) { return o.id === CP.storage.getCurrentOperationId(); })) {
      CP.storage.setCurrentOperationId(ops[0].id);
    }
    return result;
  },

  importAll: function (file, cb) {
    var reader = new FileReader();
    reader.onload = function () {
      try {
        var result = CP.storage.importParsed(JSON.parse(reader.result));
        if (cb) cb(null, result);
      } catch (e) {
        if (cb) cb(e);
      }
    };
    reader.onerror = function () { if (cb) cb(reader.error); };
    reader.readAsText(file);
  },

  // Older builds of the app-lock kept PIN/recovery hashes under cpops_security_*. Nothing reads them
  // any more, so they are dead credential material - remove them.
  purgeLegacySecurityKeys: function () {
    var dead = [];
    for (var i = 0; i < localStorage.length; i++) {
      var k = localStorage.key(i);
      if (k && k.indexOf('cpops_security_') === 0) dead.push(k);
    }
    dead.forEach(function (k) { localStorage.removeItem(k); });
    return dead.length;
  },

  // Deep-cleans a decrypted share payload value (used by CP.share).
  sanitizeImported: function (value, stats) {
    return cpSanitizeImported(value, 0, stats || { sanitized: 0 }, null);
  }
};

CP.storage.OPERATION_DATA_KEYS = CP_KNOWN_DATA_KEYS;

cpMigrateToOperationsIfNeeded();
CP.storage.purgeLegacySecurityKeys();
