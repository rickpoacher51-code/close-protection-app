window.CP = window.CP || {};
CP.disclaimer = {};

CP.disclaimer.VERSION = '1.2';
CP.disclaimer.VERSION_LABEL = 'v1.2 (20 September 2026)';
// Where the Privacy Policy lives relative to the page that shows this text (beta overrides this).
CP.disclaimer.PRIVACY_URL = 'privacy.html';

CP.disclaimer.HTML =
  '<p>By using the App, you acknowledge and agree that:</p>' +
  '<p><strong>No warranty of accuracy.</strong> The App is provided “as is” and “as available.” RD Anzen Ltd makes no representation ' +
  'or warranty, express or implied, as to the accuracy, completeness, reliability, or currency of any information entered, stored, ' +
  'generated, or displayed by the App, including but not limited to routes, venue data, contact details, medical information, or ' +
  'communications plans.</p>' +
  '<p><strong>Not professional advice.</strong> Nothing in the App constitutes security, medical, legal, or professional advice. ' +
  'All operational plans, risk assessments, and decisions remain the sole responsibility of the user and their organisation.</p>' +
  '<p><strong>Business use.</strong> The App is intended for use by security professionals and organisations in the course of their ' +
  'business or profession. It is not offered to consumers.</p>' +
  '<p><strong>User responsibility.</strong> The user is solely responsible for independently verifying all information within the App ' +
  'before relying on it in any operational context, and for exercising independent professional judgement at all times.</p>' +
  '<p><strong>Data handling.</strong> The App operates entirely on-device. All data you enter is stored locally on your device only; ' +
  'RD Anzen Ltd does not receive, transmit, store centrally, or have any access to it. RD Anzen Ltd is not responsible for loss, ' +
  'corruption, unauthorised access, or disclosure of data resulting from device loss, theft, failure, or user error.</p>' +
  '<p><strong>Limitation of liability.</strong> To the maximum extent permitted by law, RD Anzen Ltd excludes all liability for any ' +
  'indirect, incidental, special, or consequential loss or damage — including loss of data, loss of profit, or business interruption — ' +
  'arising from use of, or inability to use, the App. ' +
  // TODO (solicitor): insert the agreed aggregate liability cap for direct loss here, then bump VERSION so users re-accept.
  '</p>' +
  '<p><strong>Statutory rights preserved.</strong> Nothing in this disclaimer excludes or limits liability for death or personal injury ' +
  'caused by negligence, fraud or fraudulent misrepresentation, or any other liability which cannot lawfully be excluded or limited ' +
  'under the laws of England and Wales.</p>' +
  '<p><strong>Licence and ownership.</strong> RD Anzen Ltd grants you a limited, non-exclusive, non-transferable licence to use the App ' +
  'for your own internal business purposes. The App, its design, and its built-in templates remain the property of RD Anzen Ltd (or its licensors). ' +
  'Information you enter remains yours. You may not copy, resell, or reverse-engineer the App except as the law allows.</p>' +
  '<p><strong>Third-party links.</strong> Some buttons open Google Maps, what3words or GOV.UK in your browser. The text in those links ' +
  '(for example an address, a three-word address, or a country name) is sent to that site, which is not operated by RD Anzen Ltd and has its own terms ' +
  'and privacy policy. RD Anzen Ltd is not responsible for their content or availability.</p>' +
  '<p><strong>Your data and privacy.</strong> See the <a href="' + CP.disclaimer.PRIVACY_URL + '" target="_blank" rel="noopener noreferrer">Privacy Policy</a>. ' +
  'You are responsible for having a lawful basis to record other people’s personal data (including health information) in the App and for keeping backups and exports secure.</p>' +
  '<p><strong>Changes.</strong> RD Anzen Ltd may update the App and this disclaimer. If the text changes materially you will be asked to accept it again.</p>' +
  '<p><strong>Governing law.</strong> This disclaimer, and any dispute or claim arising out of or in connection with it or your use of the ' +
  'App, is governed by the laws of England and Wales. The courts of England and Wales have exclusive jurisdiction.</p>' +
  '<p><strong>About the provider.</strong> The App is provided by RD Anzen Ltd, a company registered in England and Wales ' +
  '(company number 08957578).</p>' +
  '<p>By continuing to use the App, you confirm that you have read, understood, and accepted this disclaimer.</p>' +
  '<p>RD Anzen Ltd — ' + CP.disclaimer.VERSION_LABEL + '</p>';

CP.disclaimer.getAcceptance = function () { return CP.storage.loadGlobal('disclaimerAcceptance', null); };

// SHA-256 of the exact text shown, stored with the acceptance so a later dispute can show which wording was accepted.
CP.disclaimer.textHash = function () {
  if (!(window.crypto && crypto.subtle)) return Promise.resolve('');
  var bytes = new TextEncoder().encode(CP.disclaimer.HTML);
  return crypto.subtle.digest('SHA-256', bytes).then(function (buf) {
    return Array.from(new Uint8Array(buf)).map(function (b) { return b.toString(16).padStart(2, '0'); }).join('');
  }).catch(function () { return ''; });
};

CP.disclaimer.isAccepted = function () {
  var rec = CP.disclaimer.getAcceptance();
  return !!(rec && rec.version === CP.disclaimer.VERSION);
};

CP.disclaimer.checkAndRun = function (onAccepted) {
  if (CP.disclaimer.isAccepted()) { onAccepted(); return; }

  var overlay = document.createElement('div');
  overlay.id = 'disclaimerOverlay';
  overlay.className = 'lock-overlay';
  overlay.innerHTML =
    '<div class="lock-card lock-card-wide">' +
    '<h2>Terms & Disclaimer</h2>' +
    '<div class="disclaimer-scroll">' + CP.disclaimer.HTML + '</div>' +
    '<button type="button" class="btn btn-primary" id="disclaimerAcceptBtn">I have read and accept</button>' +
    '</div>';
  document.body.appendChild(overlay);

  overlay.querySelector('#disclaimerAcceptBtn').addEventListener('click', function () {
    var record = { version: CP.disclaimer.VERSION, acceptedAt: new Date().toISOString() };
    CP.storage.saveGlobal('disclaimerAcceptance', record);
    CP.disclaimer.textHash().then(function (hash) {
      if (hash) { record.textSha256 = hash; CP.storage.saveGlobal('disclaimerAcceptance', record); }
    });
    overlay.remove();
    onAccepted();
  });
};
