CP.registerSegment({
  key: 'uklaws',
  label: 'UK Laws',
  icon: '⚖️',
  render: function (container) {
    // Each card carries a source link. "Last edited" is the date the wording was last changed in this app,
    // NOT a statement that a lawyer has checked it - always verify against the linked source.
    var LAWS_EDITED = '20 September 2026';
    var sections = [
      {
        title: 'SIA Licensing — Private Security Industry Act 2001',
        body: 'Close protection work in the UK is a licensable activity under the Private Security Industry Act 2001. Operatives generally require a valid SIA Close Protection licence to work in a CP role for reward. Check licence validity and renewal dates for every team member before deployment.',
        src: 'https://www.legislation.gov.uk/ukpga/2001/12'
      },
      {
        title: 'Martyn’s Law — Terrorism (Protection of Premises) Act 2025',
        body: 'Martyn’s Law places counter-terrorism duties on those responsible for qualifying public premises and events. Broadly, a “standard” tier (capacity around 200 to 799) requires basic preparedness — staff training, public protection procedures and simple measures — and an “enhanced” tier (capacity around 800+) adds a documented risk assessment, a senior individual and more substantial measures. The Security Industry Authority (SIA) is the regulator. The Act received Royal Assent on 3 April 2025 but its substantive duties are NOT yet in force: government has set an implementation period of at least 24 months from Royal Assent, and Home Office statutory guidance was published in April 2026. The date the duties commence will be set by regulations — check the current position with the Home Office / SIA before treating any venue or event as in or out of scope, and factor it into Event Security and Advance Party planning.',
        src: 'https://www.gov.uk/government/publications/the-terrorism-protection-of-premises-act-2025/terrorism-protection-of-premises-act-2025-statutory-guidance'
      },
      {
        title: 'Use of Force — Criminal Law Act 1967 s.3, Criminal Justice and Immigration Act 2008 s.76 & Common Law',
        body: 'Force used to protect the principal, yourself or others, or to prevent crime, must be reasonable in the circumstances as you honestly believed them to be. You do not have to wait to be attacked before acting — a pre-emptive act can be lawful if it is reasonable on what you honestly believed was about to happen (R v Beckford [1988] AC 130) — but force that is excessive or disproportionate is not protected. A genuinely held mistaken belief can still count; a mistake caused by voluntary intoxication cannot be relied on (s.76). In the heat of the moment you are not expected to weigh the exact amount of force to a nicety, but you must be able to justify what you did afterwards. Document any use of force as soon as practicable after the event and take legal advice.',
        src: 'https://www.legislation.gov.uk/ukpga/2008/4/section/76'
      },
      {
        title: 'Firearms — Firearms Act 1968',
        body: 'UK close protection operatives are, with very limited exception, unarmed. Carrying a firearm without the relevant certificate/authority is a serious criminal offence. Any armed CP tasking in the UK requires specific lawful authority; this is not the default position for private CP work.',
        src: 'https://www.legislation.gov.uk/ukpga/1968/27'
      },
      {
        title: 'Weapons & Restricted Items — Firearms Act 1968 s.5, Prevention of Crime Act 1953, Criminal Justice Act 1988 s.139',
        body: 'Incapacitant sprays containing CS or PAVA are prohibited weapons under s.5(1)(b) of the Firearms Act 1968; possession without authority is a serious offence and being a security operative is not an authority. Carrying an offensive weapon (an item made or adapted to cause injury, or carried with that intention — for example extendable batons or knuckledusters) in a public place without lawful authority or reasonable excuse is an offence under the Prevention of Crime Act 1953, and carrying a bladed or sharply pointed article in public without good reason is an offence under s.139 of the Criminal Justice Act 1988. Your job is not automatically accepted as a “reasonable excuse”. Keep any kit list to lawful items and check the law for every country you travel to.',
        src: 'https://www.legislation.gov.uk/ukpga/Eliz2/1-2/14'
      },
      {
        title: 'Powers of Arrest / Detention — PACE 1984',
        body: 'CP operatives have no special police-style powers. Any detention is limited to the citizen’s arrest power under s.24A PACE (indictable offence, necessity, reasonable grounds) and must be handed to police without unreasonable delay. Unlawful detention can expose the operative and employer to civil and criminal liability.',
        src: 'https://www.legislation.gov.uk/ukpga/1984/60/section/24A'
      },
      {
        title: 'Data Protection — Data Protection Act 2018 / UK GDPR',
        body: 'Notes, logs, photographs, route plans, and medical details you record in this app are personal data, and YOU (or your organisation) are the controller of them. Handle them under data minimisation, purpose limitation, and security principles: restrict access, do not retain longer than necessary, and have a lawful basis (typically contract or legitimate interests) for processing the principal’s data. Health information — blood type, allergies, conditions, medications — is “special category” data: as well as a lawful basis you need an Article 9 condition (commonly the person’s explicit consent, or vital interests in an emergency), and high-risk processing may need a data protection impact assessment. Only record what the person has agreed to share. Backups and exports made from this app are not encrypted unless you use the encrypted share option, so store and send them accordingly.',
        src: 'https://www.legislation.gov.uk/ukpga/2018/12'
      },
      {
        title: 'Driving — Road Traffic Act 1988',
        body: 'CP drivers hold no special exemptions from speed limits, traffic signals, or the general duty of care. Advanced driving qualifications reduce risk but do not confer legal privilege. Any incident involving a CP vehicle is assessed under ordinary road traffic law.',
        src: 'https://www.legislation.gov.uk/ukpga/1988/52'
      },
      {
        title: 'Health & Safety — Health and Safety at Work etc. Act 1974',
        body: 'Employers and self-employed operatives have duties to assess and manage risk to themselves, colleagues, and others affected by the work, including dynamic risk assessment for advance work, events, and travel.',
        src: 'https://www.legislation.gov.uk/ukpga/1974/37'
      }
    ];

    var accordionHtml = sections.map(function (s, i) {
      var src = CP.ui.safeUrl(s.src);
      return '<details class="law-item"' + (i === 0 ? ' open' : '') + '><summary>' +
        CP.ui.escapeHtml(s.title) + '</summary><p>' + CP.ui.escapeHtml(s.body) + '</p>' +
        '<p class="hint">Wording last edited: ' + CP.ui.escapeHtml(LAWS_EDITED) + '.' +
        (src ? ' <a href="' + CP.ui.escapeHtml(src) + '" target="_blank" rel="noopener noreferrer">Source</a>' : '') + '</p></details>';
    }).join('');

    container.innerHTML =
      '<h1>UK Laws — Reference</h1>' +
      '<div class="disclaimer"><strong>Not legal advice.</strong> This is general reference material for awareness only. ' +
      'Laws, case law, and licensing requirements change — verify against current legislation and take advice from a solicitor ' +
      'or your company’s legal advisor before making operational or employment decisions.</div>' +
      '<div class="law-list">' + accordionHtml + '</div>' +
      '<section class="panel"><h2>Unit Notes</h2><div id="uklawsNotes"></div></section>' +
      '<section class="panel"><h2>App Terms & Disclaimer</h2><div id="disclaimerRecord"></div></section>';

    CP.ui.profileForm(container.querySelector('#uklawsNotes'), {
      storageKey: 'uklawsNotes',
      fields: [
        { key: 'notes', label: 'Notes (e.g. company policy references, licence renewal dates)', type: 'textarea' }
      ]
    });

    var acceptance = CP.disclaimer.getAcceptance();
    var recordHtml = acceptance
      ? '<p class="hint">Accepted on this device: <strong>' + CP.ui.escapeHtml(new Date(acceptance.acceptedAt).toLocaleString()) +
        '</strong> (version ' + CP.ui.escapeHtml(acceptance.version) + ')</p>'
      : '<p class="hint">Not yet recorded on this device.</p>';
    container.querySelector('#disclaimerRecord').innerHTML =
      recordHtml + '<details class="law-item"><summary>View full text</summary><div class="disclaimer-scroll" style="max-height:none;">' +
      CP.disclaimer.HTML + '</div></details>';
  }
});
