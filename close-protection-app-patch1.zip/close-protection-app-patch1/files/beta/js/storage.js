window.CP = window.CP || {};

// The beta shares a browser origin with the production app (cpapp_*), and the two use different
// operation-id formats. A separate prefix keeps the beta's data, PIN/lock config and terms
// acceptance completely apart from production. (Beta backups made before this change hold their
// keys without a prefix - export from the old beta first, then Import after deploying.)
CP.PREFIX = 'cpbeta_';
CP.NAV = [];
CP.segments = {};

CP.registerSegment = function (seg) {
  CP.segments[seg.key] = seg;
  CP.NAV.push(seg);
};

// Keys that are NOT scoped to a single operation — they describe the
// operation registry itself, or app-wide device/browser settings.

// Every write goes through here so a full/blocked browser store is never silent.
var cpLastStorageAlert = 0;
function cpSafeSetItem(fullKey, str) {
  try {
    localStorage.setItem(fullKey, str);
  } catch (e) {
    var now = Date.now();
    if (now - cpLastStorageAlert > 4000) {
      cpLastStorageAlert = now;
      alert('Could not save: this browser\u2019s storage is full or blocked, so your last change was NOT saved. ' +
        'Export a backup now, then free up space by deleting old operations.');
    }
    if (e && typeof e === 'object') e.cpAlerted = true;
    throw e;
  }
}

// --- Import hardening: backup files are untrusted input. Only allow-listed keys are written and
// every value is cleaned first (bad ids replaced, unsafe values rejected).
var CP_NEVER_IMPORT = ['appLock', 'disclaimerAcceptance', 'lockAttempts', 'lastBackup'];
var CP_OPID_RE = /^id_[a-z0-9]+_[a-z0-9]+$/;
var CP_SCOPED_KEY_RE = /^op_id_[a-z0-9]+_[a-z0-9]+_[A-Za-z0-9]{1,64}$/;
var CP_SHORT_KEY_RE = /^[A-Za-z0-9]{1,64}$/;
var CP_MAX_STRING = 500000;
var CP_BAD_KEYS = ['__proto__', 'constructor', 'prototype'];

function cpSanitizeImported(v, depth, stats, fieldName) {
  depth = depth || 0;
  if (depth > 10) throw new Error('nesting too deep');
  if (v === null || typeof v === 'boolean') return v;
  if (typeof v === 'number') { if (!isFinite(v)) throw new Error('bad number'); return v; }
  if (typeof v === 'string') {
    if (fieldName === 'id' && !CP.ui.safeId(v)) { stats.sanitized++; return CP.storage.uid(); }
    if (v.length > CP_MAX_STRING) throw new Error('string too long');
    return v;
  }
  if (Array.isArray(v)) {
    if (v.length > 20000) throw new Error('array too long');
    return v.map(function (x) { return cpSanitizeImported(x, depth + 1, stats, null); });
  }
  if (typeof v === 'object') {
    var keys = Object.keys(v);
    if (keys.length > 500) throw new Error('object too large');
    var out = {};
    keys.forEach(function (k) {
      if (CP_BAD_KEYS.indexOf(k) !== -1) { stats.sanitized++; return; }
      out[k] = cpSanitizeImported(v[k], depth + 1, stats, k);
    });
    return out;
  }
  throw new Error('unsupported value');
}

function cpCleanOperations(list, stats) {
  if (!Array.isArray(list)) throw new Error('operations must be a list');
  var clean = [];
  list.forEach(function (o) {
    if (!o || typeof o !== 'object' || !CP_OPID_RE.test(String(o.id || ''))) { stats.sanitized++; return; }
    clean.push({
      id: o.id,
      name: String(o.name || 'Operation').slice(0, 200),
      client: String(o.client || '').slice(0, 200),
      status: ['planning', 'live', 'complete'].indexOf(o.status) !== -1 ? o.status : 'planning',
      createdAt: isNaN(new Date(o.createdAt).getTime()) ? new Date().toISOString() : new Date(o.createdAt).toISOString()
    });
  });
  return clean;
}

// Writes one allow-listed key (already stripped of the prefix). Returns true if written.
function cpImportKey(k, value, stats) {
  if (typeof k !== 'string' || CP_NEVER_IMPORT.indexOf(k) !== -1) return false;
  var clean;
  if (k === 'operations') clean = cpCleanOperations(value, stats);
  else if (k === 'currentOpId') {
    if (!CP_OPID_RE.test(String(value || ''))) return false;
    clean = value;
  } else if (k === 'legacyMigrated') {
    clean = true;
  } else if (k === 'deviceLabel') {
    if (typeof value !== 'string') return false;
    clean = value.slice(0, 80);
  } else if (CP_SCOPED_KEY_RE.test(k)) {
    clean = cpSanitizeImported(value, 0, stats, null);
  } else return false;
  CP.storage._rawSave(k, clean);
  return true;
}

CP.storage = {
  GLOBAL_KEYS: ['operations', 'currentOpId', 'legacyMigrated', 'deviceLabel'],

  _rawKey: function (key) {
    return CP.PREFIX + key;
  },

  _rawLoad: function (key, fallback) {
    try {
      var raw = localStorage.getItem(CP.storage._rawKey(key));
      if (raw === null) return fallback;
      return JSON.parse(raw);
    } catch (e) {
      console.error('CP storage load failed for', key, e);
      return fallback;
    }
  },

  _rawSave: function (key, value) {
    cpSafeSetItem(CP.storage._rawKey(key), JSON.stringify(value));
  },

  // Aliases so shared code (the terms/disclaimer screen) works on both builds.
  loadGlobal: function (key, fallback) { return CP.storage._rawLoad(key, fallback); },
  saveGlobal: function (key, value) { CP.storage._rawSave(key, value); },
  removeGlobal: function (key) { localStorage.removeItem(CP.storage._rawKey(key)); },

  // Segment-facing key: automatically namespaced under the current
  // operation unless it's a known global key. Segment files never need
  // to know this is happening.
  _scopedKey: function (key) {
    if (CP.storage.GLOBAL_KEYS.indexOf(key) !== -1) return key;
    return 'op_' + CP.ops.current() + '_' + key;
  },

  load: function (key, fallback) {
    return CP.storage._rawLoad(CP.storage._scopedKey(key), fallback);
  },

  save: function (key, value) {
    CP.storage._rawSave(CP.storage._scopedKey(key), value);
  },

  uid: function () {
    return 'id_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 8);
  },

  // Exports the CURRENT operation only: a clean single-op backup/handover file.
  exportCurrentOp: function () {
    var opId = CP.ops.current();
    var opRecord = CP.ops.get(opId);
    var out = { _exportType: 'single-operation', _operation: opRecord, data: {} };
    var prefix = CP.PREFIX + 'op_' + opId + '_';
    for (var i = 0; i < localStorage.length; i++) {
      var k = localStorage.key(i);
      if (k.indexOf(prefix) === 0) {
        try {
          out.data[k.slice(prefix.length)] = JSON.parse(localStorage.getItem(k));
        } catch (e) {
          // skip unreadable entry
        }
      }
    }
    var stamp = new Date().toISOString().slice(0, 10);
    var name = 'cp-ops-' + CP.ui.slug(opRecord ? opRecord.name : 'operation') + '-' + stamp + '.json';
    CP.storage._downloadJson(out, name);
  },

  // Exports every operation plus the registry itself — a full-app backup.
  exportAllOperations: function () {
    var out = { _exportType: 'full-backup', data: {} };
    for (var i = 0; i < localStorage.length; i++) {
      var k = localStorage.key(i);
      if (k.indexOf(CP.PREFIX) === 0 && CP_NEVER_IMPORT.indexOf(k.slice(CP.PREFIX.length)) === -1) {
        try {
          out.data[k.slice(CP.PREFIX.length)] = JSON.parse(localStorage.getItem(k));
        } catch (e) {
          // skip unreadable entry
        }
      }
    }
    var stamp = new Date().toISOString().slice(0, 10);
    CP.storage._downloadJson(out, 'cp-ops-full-backup-' + stamp + '.json');
  },

  _downloadJson: function (obj, filename) {
    var blob = new Blob([JSON.stringify(obj, null, 2)], { type: 'application/json' });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  },

  // Accepts either beta export shape (full-backup or single-operation). Every key and value is
  // validated first. cb(err, { mode, opName?, imported, skipped, sanitized }).
  importAll: function (file, cb) {
    var reader = new FileReader();
    reader.onload = function () {
      try {
        var parsed = JSON.parse(reader.result);
        if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) throw new Error('not a backup');
        var stats = { sanitized: 0 };
        var result = { imported: 0, skipped: 0, sanitized: 0 };

        if (parsed._exportType === 'full-backup' && parsed.data && typeof parsed.data === 'object') {
          Object.keys(parsed.data).forEach(function (k) {
            var ok = false;
            try { ok = cpImportKey(k, parsed.data[k], stats); } catch (e) { ok = false; }
            if (ok) result.imported++; else result.skipped++;
          });
          var ops = CP.ops.list();
          if (ops.length && !ops.some(function (o) { return o.id === CP.storage._rawLoad('currentOpId', null); })) {
            CP.ops.setCurrent(ops[0].id);
          }
          result.mode = 'full-backup';
        } else if (parsed._exportType === 'single-operation' && parsed.data && typeof parsed.data === 'object') {
          var srcOp = parsed._operation && typeof parsed._operation === 'object' ? parsed._operation : {};
          var srcName = typeof srcOp.name === 'string' ? srcOp.name.slice(0, 160) : '';
          var newOp = CP.ops.create(srcName ? srcName + ' (imported)' : 'Imported Operation',
            typeof srcOp.client === 'string' ? srcOp.client.slice(0, 200) : '');
          Object.keys(parsed.data).forEach(function (k) {
            if (!CP_SHORT_KEY_RE.test(k) || CP.storage.GLOBAL_KEYS.indexOf(k) !== -1 || CP_NEVER_IMPORT.indexOf(k) !== -1) { result.skipped++; return; }
            try {
              CP.storage._rawSave('op_' + newOp.id + '_' + k, cpSanitizeImported(parsed.data[k], 0, stats, null));
              result.imported++;
            } catch (e) { result.skipped++; }
          });
          CP.ops.setCurrent(newOp.id);
          result.mode = 'single-operation';
          result.opName = newOp.name;
        } else if (Array.isArray(parsed.operations) || parsed.currentOperationId) {
          // A backup from the production app: different storage format - refuse rather than write junk.
          throw new Error('production backup');
        } else {
          // Legacy flat export (pre-operations version of the app) - import into the current operation.
          var opId = CP.ops.current();
          Object.keys(parsed).forEach(function (k) {
            if (!CP_SHORT_KEY_RE.test(k) || CP.storage.GLOBAL_KEYS.indexOf(k) !== -1 || CP_NEVER_IMPORT.indexOf(k) !== -1) { result.skipped++; return; }
            try {
              CP.storage._rawSave('op_' + opId + '_' + k, cpSanitizeImported(parsed[k], 0, stats, null));
              result.imported++;
            } catch (e) { result.skipped++; }
          });
          result.mode = 'legacy';
        }
        result.sanitized = stats.sanitized;
        if (cb) cb(null, result);
      } catch (e) {
        if (cb) cb(e);
      }
    };
    reader.onerror = function () { if (cb) cb(reader.error); };
    reader.readAsText(file);
  }
};

// --- Operations registry -----------------------------------------------
// Everything in the app now lives "inside" an operation. On first load
// after this update, any pre-existing data (from before operations
// existed) is migrated into a default "Operation 1" so nothing is lost.

CP.ops = {
  list: function () {
    return CP.storage._rawLoad('operations', []);
  },

  get: function (id) {
    return CP.ops.list().filter(function (o) { return o.id === id; })[0] || null;
  },

  save: function (list) {
    CP.storage._rawSave('operations', list);
  },

  create: function (name, client) {
    var op = {
      id: CP.storage.uid(),
      name: name || 'New Operation',
      client: client || '',
      status: 'planning', // planning | live | complete
      createdAt: new Date().toISOString()
    };
    var list = CP.ops.list();
    list.push(op);
    CP.ops.save(list);
    return op;
  },

  update: function (id, patch) {
    var list = CP.ops.list().map(function (o) {
      return o.id === id ? Object.assign({}, o, patch) : o;
    });
    CP.ops.save(list);
  },

  current: function () {
    CP.ops._ensureInit();
    return CP.storage._rawLoad('currentOpId', null);
  },

  setCurrent: function (id) {
    CP.storage._rawSave('currentOpId', id);
  },

  _ensureInit: function () {
    if (CP.storage._rawLoad('legacyMigrated', false)) return;

    var list = CP.ops.list();
    if (list.length) {
      CP.storage._rawSave('legacyMigrated', true);
      if (!CP.storage._rawLoad('currentOpId', null)) CP.ops.setCurrent(list[0].id);
      return;
    }

    // No operations registered yet. Check for legacy flat-format data
    // (anything under cpapp_ that isn't itself a global key) and, if
    // found, migrate it into a new default operation rather than losing it.
    var legacyKeys = [];
    for (var i = 0; i < localStorage.length; i++) {
      var k = localStorage.key(i);
      if (k.indexOf(CP.PREFIX) !== 0) continue;
      var short = k.slice(CP.PREFIX.length);
      if (CP.storage.GLOBAL_KEYS.indexOf(short) !== -1) continue;
      if (short.indexOf('op_') === 0) continue; // already scoped, not legacy
      legacyKeys.push(short);
    }

    var op = CP.ops.create('Operation 1');

    legacyKeys.forEach(function (short) {
      var raw = localStorage.getItem(CP.PREFIX + short);
      localStorage.setItem(CP.PREFIX + 'op_' + op.id + '_' + short, raw);
      localStorage.removeItem(CP.PREFIX + short);
    });

    CP.ops.setCurrent(op.id);
    CP.storage._rawSave('legacyMigrated', true);
  }
};
